"""Google Document AI backend for pdfsmith.

Google Cloud Document AI provides commercial-grade OCR and document understanding.

Requirements:
    - google-cloud-documentai
    - google-cloud-storage (for batch processing of large documents)

Configuration:
    Set GOOGLE_APPLICATION_CREDENTIALS (path to service account JSON),
    GOOGLE_CLOUD_PROJECT (project ID), and
    GOOGLE_DOCUMENT_AI_PROCESSOR_ID.

    For documents > 15 pages, also set GOOGLE_DOCUMENT_AI_GCS_BUCKET
    (a GCS bucket for temporary upload/download during batch processing).

Cost: $1.50 per 1,000 pages (Document OCR)
Limits: 15 pages (synchronous), 500 pages (batch with GCS)
"""

import json
import logging
import time
import uuid
from pathlib import Path

try:
    from google.api_core.client_options import ClientOptions
    from google.cloud import documentai_v1 as documentai

    AVAILABLE = True
except ImportError:
    AVAILABLE = False

try:
    from google.cloud import storage as gcs

    GCS_AVAILABLE = True
except ImportError:
    GCS_AVAILABLE = False

from pdfsmith.backends.registry import BaseBackend

logger = logging.getLogger(__name__)

SYNC_PAGE_LIMIT = 15
SYNC_SIZE_LIMIT_MB = 20
BATCH_PAGE_LIMIT = 500


class GoogleDocumentAIBackend(BaseBackend):
    """Google Document AI backend for pdfsmith."""

    name = "google_document_ai"

    def __init__(self) -> None:
        """Initialize Google Document AI backend."""
        if not AVAILABLE:
            raise ImportError(
                "google-cloud-documentai is required for Google Document AI. "
                "Install with: pip install google-cloud-documentai"
            )

        import os

        credentials_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
        project_id = os.getenv("GOOGLE_CLOUD_PROJECT")
        self._location = os.getenv("GOOGLE_CLOUD_LOCATION", "us")
        processor_id = os.getenv("GOOGLE_DOCUMENT_AI_PROCESSOR_ID")
        self._gcs_bucket = os.getenv("GOOGLE_DOCUMENT_AI_GCS_BUCKET")

        if not credentials_path:
            raise RuntimeError(
                "GOOGLE_APPLICATION_CREDENTIALS must be set. "
                "Point it to your service account JSON file."
            )

        if not project_id:
            raise RuntimeError("GOOGLE_CLOUD_PROJECT must be set")

        if not processor_id:
            raise RuntimeError(
                "GOOGLE_DOCUMENT_AI_PROCESSOR_ID must be set. "
                "Create an OCR processor in Google Cloud Console."
            )

        # Initialize client
        opts = ClientOptions(
            api_endpoint=f"{self._location}-documentai.googleapis.com"
        )
        self.client = documentai.DocumentProcessorServiceClient(client_options=opts)

        # Store processor name
        self.processor_name = (
            f"projects/{project_id}/locations/{self._location}/processors/{processor_id}"
        )

    def _get_page_count(self, pdf_path: Path) -> int | None:
        """Get page count using PyMuPDF if available."""
        try:
            import fitz

            pdf_doc = fitz.open(pdf_path)
            count = len(pdf_doc)
            pdf_doc.close()
            return count
        except ImportError:
            return None

    def parse(self, pdf_path: Path) -> str:
        """Parse PDF to markdown using Google Document AI.

        Automatically uses sync API for small documents (<= 15 pages)
        and batch API for larger ones.
        """
        if not pdf_path.exists():
            raise FileNotFoundError(f"PDF not found: {pdf_path}")

        page_count = self._get_page_count(pdf_path)
        file_size_mb = pdf_path.stat().st_size / (1024 * 1024)

        if page_count is not None and page_count > BATCH_PAGE_LIMIT:
            raise ValueError(
                f"PDF has {page_count} pages. "
                f"Google Document AI limit is {BATCH_PAGE_LIMIT} pages."
            )

        use_batch = (
            (page_count is not None and page_count > SYNC_PAGE_LIMIT)
            or file_size_mb > SYNC_SIZE_LIMIT_MB
        )

        if use_batch:
            return self._parse_batch(pdf_path)
        return self._parse_sync(pdf_path)

    def _parse_sync(self, pdf_path: Path) -> str:
        """Parse using synchronous API (up to 15 pages / 20 MB)."""
        try:
            pdf_content = pdf_path.read_bytes()
            raw_document = documentai.RawDocument(
                content=pdf_content, mime_type="application/pdf"
            )
            request = documentai.ProcessRequest(
                name=self.processor_name, raw_document=raw_document
            )
            result = self.client.process_document(request=request)
            return self._extract_text(result.document)
        except Exception as e:
            self._raise_api_error(e)

    def _parse_batch(self, pdf_path: Path) -> str:
        """Parse using batch API via GCS (up to 500 pages)."""
        if not GCS_AVAILABLE:
            raise ImportError(
                "google-cloud-storage is required for batch processing. "
                "Install with: pip install google-cloud-storage"
            )

        if not self._gcs_bucket:
            raise RuntimeError(
                "GOOGLE_DOCUMENT_AI_GCS_BUCKET must be set for documents > 15 pages. "
                "Provide a GCS bucket name for temporary file staging."
            )

        storage_client = gcs.Client()
        bucket = storage_client.bucket(self._gcs_bucket)
        job_id = uuid.uuid4().hex[:12]
        gcs_input = f"pdfsmith-tmp/{job_id}/input/{pdf_path.name}"
        gcs_output_prefix = f"pdfsmith-tmp/{job_id}/output/"

        try:
            # Upload PDF to GCS
            logger.info(
                "Uploading %s to gs://%s/%s",
                pdf_path.name, self._gcs_bucket, gcs_input,
            )
            blob = bucket.blob(gcs_input)
            blob.upload_from_filename(str(pdf_path))

            # Submit batch request
            gcs_document = documentai.GcsDocument(
                gcs_uri=f"gs://{self._gcs_bucket}/{gcs_input}",
                mime_type="application/pdf",
            )
            gcs_documents = documentai.GcsDocuments(documents=[gcs_document])
            input_config = documentai.BatchDocumentsInputConfig(
                gcs_documents=gcs_documents,
            )

            output_config = documentai.DocumentOutputConfig(
                gcs_output_config=documentai.DocumentOutputConfig.GcsOutputConfig(
                    gcs_uri=f"gs://{self._gcs_bucket}/{gcs_output_prefix}",
                )
            )

            request = documentai.BatchProcessRequest(
                name=self.processor_name,
                input_documents=input_config,
                document_output_config=output_config,
            )

            logger.info("Submitting batch process request for %s", pdf_path.name)
            operation = self.client.batch_process_documents(request=request)

            # Poll for completion
            start = time.monotonic()
            operation.result(timeout=600)
            elapsed = time.monotonic() - start
            logger.info("Batch processing completed in %.1fs", elapsed)

            # Read output from GCS
            return self._read_batch_output(bucket, gcs_output_prefix)

        finally:
            # Clean up GCS artifacts
            self._cleanup_gcs(bucket, f"pdfsmith-tmp/{job_id}/")

    def _read_batch_output(self, bucket, output_prefix: str) -> str:
        """Read and combine batch processing output from GCS."""
        blobs = list(bucket.list_blobs(prefix=output_prefix))
        json_blobs = [b for b in blobs if b.name.endswith(".json")]

        if not json_blobs:
            raise RuntimeError(
                f"No output found at gs://{bucket.name}/{output_prefix}. "
                "Batch processing may have failed silently."
            )

        # Each JSON blob contains a Document proto as JSON
        all_text = []
        for blob in sorted(json_blobs, key=lambda b: b.name):
            content = blob.download_as_text()
            doc_dict = json.loads(content)
            document = documentai.Document.from_json(json.dumps(doc_dict))
            text = self._extract_text(document)
            if text:
                all_text.append(text)

        return "\n\n".join(all_text).strip()

    def _cleanup_gcs(self, bucket, prefix: str) -> None:
        """Delete temporary GCS objects."""
        try:
            blobs = list(bucket.list_blobs(prefix=prefix))
            for blob in blobs:
                blob.delete()
            logger.debug("Cleaned up %d GCS objects under %s", len(blobs), prefix)
        except Exception as e:
            logger.warning("Failed to clean up GCS objects: %s", e)

    def _extract_text(self, document) -> str:
        """Extract text from Document AI response."""
        # document.text contains the full extracted text
        if document.text:
            return document.text.strip()

        # Fallback: reconstruct from page lines
        text_blocks = []
        if document.pages:
            for page in document.pages:
                if page.lines:
                    for line in page.lines:
                        text = self._get_text_from_layout(line.layout, document.text)
                        if text:
                            text_blocks.append(text)

        return "\n\n".join(text_blocks).strip()

    def _get_text_from_layout(self, layout, document_text: str) -> str:
        """Extract text from layout using text anchors."""
        if not layout.text_anchor or not layout.text_anchor.text_segments:
            return ""

        text_parts = []
        for segment in layout.text_anchor.text_segments:
            start = int(segment.start_index) if segment.start_index else 0
            end = int(segment.end_index) if segment.end_index else len(document_text)
            text_parts.append(document_text[start:end])

        return "".join(text_parts)

    @staticmethod
    def _raise_api_error(e: Exception) -> None:
        """Raise a descriptive error from a Document AI API exception."""
        error_msg = str(e)
        if "INVALID_ARGUMENT" in error_msg:
            raise ValueError(f"Invalid PDF: {error_msg}") from e
        elif "RESOURCE_EXHAUSTED" in error_msg:
            raise RuntimeError(f"Google rate limit exceeded: {error_msg}") from e
        else:
            raise RuntimeError(f"Google Document AI error: {error_msg}") from e
