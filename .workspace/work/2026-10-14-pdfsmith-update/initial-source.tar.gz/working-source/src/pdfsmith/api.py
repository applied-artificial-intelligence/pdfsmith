"""
Core API for pdfsmith.

Provides a simple interface to parse PDFs and images to markdown using various backends.

API Levels:
    Level 1 (Simple): parse("document.pdf") - auto-select backend, defaults
    Level 2 (Common): parse("document.pdf", preset="best", ocr=True) - cross-backend options
    Level 3 (Advanced): parse("document.pdf", backend_options={...}) - backend-specific

Configuration Sources (in order of precedence):
    1. Explicit API arguments (preset, ocr, backend_options)
    2. Environment variables (PDFSMITH_<BACKEND>_<OPTION>)
    3. Config files (.pdfsmith/<backend>.yaml, ~/.config/pdfsmith/<backend>.yaml)
    4. Built-in defaults
"""

from pathlib import Path
from typing import Any, Literal

from pdfsmith.backends.registry import BACKEND_REGISTRY, BackendInfo

# Backend preference order (best first, considering quality vs availability)
DEFAULT_PREFERENCE = [
    "docling",  # Best quality, heavy
    "marker",  # Great for academic docs
    "pymupdf4llm",  # Good balance
    "kreuzberg",  # Fast, good quality
    "unstructured",  # Versatile
    "pdfplumber",  # Reliable for tables
    "pymupdf",  # Fast, basic
    "pypdf",  # Lightweight fallback
    "pdfminer",  # Legacy but works
    "pypdfium2",  # Alternative
    "extractous",  # Rust-based
]

# Image preference order (for image inputs)
IMAGE_PREFERENCE = [
    "docling",  # InputFormat.IMAGE support
    "kreuzberg",  # Native image OCR
    "extractous",  # Tesseract-based
]

# Backends that support image input
IMAGE_CAPABLE_BACKENDS = {
    "docling",
    "kreuzberg",
    "extractous",
    # Commercial APIs (all support images)
    "aws_textract",
    "azure_document_intelligence",
    "google_document_ai",
    "databricks",
    "llamaparse",
    # LLM vision APIs
    "anthropic",
    "openai",
    "gemini",
}

# Supported image extensions
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".tiff", ".webp", ".bmp"}

BackendName = Literal[
    # Open source
    "docling",
    "marker",
    "pymupdf4llm",
    "kreuzberg",
    "unstructured",
    "pdfplumber",
    "pymupdf",
    "pypdf",
    "pdfminer",
    "pypdfium2",
    "extractous",
    # Commercial
    "aws_textract",
    "azure_document_intelligence",
    "google_document_ai",
    "databricks",
    "llamaparse",
    # LLM Vision
    "anthropic",
    "openai",
    "gemini",
]

PresetName = Literal["fast", "balanced", "best"]

# Preset configurations per backend
# These are applied when a preset is specified
PRESETS: dict[str, dict[str, dict[str, Any]]] = {
    "fast": {
        "docling": {"do_ocr": False, "do_table_structure": False},
        "marker": {"force_ocr": False, "use_llm": False},
        "unstructured": {"strategy": "fast"},
        "pdfplumber": {"layout": False},
        "pdfminer": {"boxes_flow": None},
        "kreuzberg": {"force_ocr": False},
    },
    "balanced": {
        "docling": {"do_ocr": False, "do_table_structure": True},
        "marker": {"force_ocr": False, "use_llm": False},
        "unstructured": {"strategy": "auto"},
        "pdfplumber": {"layout": False},
        "pdfminer": {"boxes_flow": 0.5},
        "kreuzberg": {"force_ocr": False},
    },
    "best": {
        "docling": {"do_ocr": True, "do_table_structure": True},
        "marker": {"force_ocr": True, "use_llm": True},
        "unstructured": {"strategy": "hi_res", "infer_table_structure": True},
        "pdfplumber": {"layout": True},
        "pdfminer": {"boxes_flow": 0.5, "detect_vertical": True, "all_texts": True},
        "kreuzberg": {"force_ocr": True},
    },
}


def available_backends() -> list[BackendInfo]:
    """Return list of available (installed) backends with their info."""
    available = []
    for name in DEFAULT_PREFERENCE:
        if name in BACKEND_REGISTRY:
            info = BACKEND_REGISTRY[name]
            if info.is_available():
                available.append(info)
    return available


def get_backend(
    name: BackendName | None = None,
    *,
    backend_options: dict[str, Any] | None = None,
    for_image: bool = False,
):
    """
    Get a backend instance by name, or auto-select the best available.

    Args:
        name: Backend name, or None to auto-select
        backend_options: Options to pass to backend constructor
        for_image: If True, only consider image-capable backends for auto-select

    Returns:
        Backend instance ready to parse

    Raises:
        ImportError: If specified backend is not installed
        RuntimeError: If no backends are available
        ValueError: If backend doesn't support images but for_image=True
    """
    backend_options = backend_options or {}

    if name is not None:
        if name not in BACKEND_REGISTRY:
            available = list(BACKEND_REGISTRY.keys())
            raise ValueError(f"Unknown backend: {name}. Available: {available}")

        # Check image support
        if for_image and name not in IMAGE_CAPABLE_BACKENDS:
            raise ValueError(
                f"Backend '{name}' does not support image inputs. "
                f"Image-capable backends: {sorted(IMAGE_CAPABLE_BACKENDS)}"
            )

        info = BACKEND_REGISTRY[name]
        if not info.is_available():
            raise ImportError(
                f"Backend '{name}' is not installed. "
                f"Install with: pip install pdfsmith[{name}]"
            )

        # Create instance with options
        backend_class = info.loader()
        return backend_class(**backend_options)

    # Auto-select best available
    preference = IMAGE_PREFERENCE if for_image else DEFAULT_PREFERENCE

    for backend_name in preference:
        if backend_name in BACKEND_REGISTRY:
            # Skip non-image backends when for_image
            if for_image and backend_name not in IMAGE_CAPABLE_BACKENDS:
                continue

            info = BACKEND_REGISTRY[backend_name]
            if info.is_available():
                backend_class = info.loader()
                return backend_class(**backend_options)

    if for_image:
        raise RuntimeError(
            "No image-capable backends are installed. "
            "Install with: pip install pdfsmith[docling] or pdfsmith[kreuzberg]"
        )
    raise RuntimeError(
        "No PDF parsing backends are installed. "
        "Install with: pip install pdfsmith[light] or pdfsmith[recommended]"
    )


def _build_backend_options(
    backend_name: str,
    preset: PresetName | None,
    ocr: bool | str | None,
    backend_options: dict[str, Any] | None,
) -> dict[str, Any]:
    """Build merged backend options from preset, common params, and explicit options.

    Priority (highest to lowest):
        1. Explicit backend_options
        2. Common options (ocr)
        3. Preset options
    """
    merged: dict[str, Any] = {}

    # 1. Apply preset if specified
    if preset and backend_name in PRESETS.get(preset, {}):
        merged.update(PRESETS[preset][backend_name])

    # 2. Apply common OCR option (translate to backend-specific key)
    if ocr is not None:
        # Map common 'ocr' param to backend-specific option
        ocr_mappings = {
            "docling": "do_ocr",
            "marker": "force_ocr",
            "kreuzberg": "force_ocr",
            "unstructured": "ocr_languages",  # Triggers OCR if non-empty
        }
        if backend_name in ocr_mappings:
            key = ocr_mappings[backend_name]
            if isinstance(ocr, bool):
                merged[key] = ocr
            elif isinstance(ocr, str):
                # OCR with languages (e.g., "eng+deu")
                merged[key] = True
                if backend_name == "docling":
                    merged["ocr_languages"] = ocr.split("+")
                elif backend_name in ("kreuzberg", "unstructured"):
                    merged["ocr_languages"] = ocr

    # 3. Override with explicit backend_options
    if backend_options:
        merged.update(backend_options)

    return merged


def parse(
    input_path: str | Path,
    *,
    backend: BackendName | None = None,
    preset: PresetName | None = None,
    ocr: bool | str | None = None,
    backend_options: dict[str, Any] | None = None,
) -> str:
    """
    Parse a PDF or image file to markdown.

    This is the main entry point for pdfsmith. It supports three levels of usage:

    Level 1 - Simple (defaults):
        markdown = parse("document.pdf")

    Level 2 - Common options (cross-backend):
        markdown = parse("document.pdf", preset="best", ocr=True)

    Level 3 - Backend-specific options:
        markdown = parse("document.pdf", backend="docling",
                        backend_options={"do_table_structure": True, "device": "cuda"})

    Args:
        input_path: Path to the input file (PDF or image)
        backend: Backend to use, or None to auto-select best available
        preset: Quality preset ("fast", "balanced", "best"). Affects multiple backends.
        ocr: Enable OCR. True/False or language string like "eng+deu".
        backend_options: Backend-specific options (highest priority)

    Returns:
        Markdown string extracted from the document

    Examples:
        # Auto-select backend
        markdown = parse("document.pdf")

        # Use specific backend
        markdown = parse("document.pdf", backend="docling")

        # Use preset for quality/speed tradeoff
        markdown = parse("document.pdf", preset="best")

        # Enable OCR with specific languages
        markdown = parse("scan.pdf", ocr="eng+deu")

        # Full control with backend-specific options
        markdown = parse("document.pdf", backend="docling",
                        backend_options={"do_ocr": True, "device": "cuda"})

        # Parse image files (auto-selects image-capable backend)
        markdown = parse("scan.png")
    """
    input_path = Path(input_path)
    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    # Detect input type
    suffix = input_path.suffix.lower()
    is_image = suffix in IMAGE_EXTENSIONS

    # Determine backend name for option building
    backend_name = backend
    if backend_name is None:
        # Peek at which backend will be selected
        preference = IMAGE_PREFERENCE if is_image else DEFAULT_PREFERENCE
        for name in preference:
            if name in BACKEND_REGISTRY and BACKEND_REGISTRY[name].is_available():
                if not is_image or name in IMAGE_CAPABLE_BACKENDS:
                    backend_name = name
                    break

    # Build merged options
    merged_options = _build_backend_options(
        backend_name or "docling",  # Fallback for option building
        preset,
        ocr,
        backend_options,
    )

    # Get backend instance with options
    backend_instance = get_backend(backend, backend_options=merged_options, for_image=is_image)
    return backend_instance.parse(input_path)


async def parse_async(
    input_path: str | Path,
    *,
    backend: BackendName | None = None,
    preset: PresetName | None = None,
    ocr: bool | str | None = None,
    backend_options: dict[str, Any] | None = None,
) -> str:
    """
    Parse a PDF or image file to markdown asynchronously.

    See parse() for full documentation of arguments and examples.

    Args:
        input_path: Path to the input file (PDF or image)
        backend: Backend to use, or None to auto-select best available
        preset: Quality preset ("fast", "balanced", "best")
        ocr: Enable OCR. True/False or language string like "eng+deu"
        backend_options: Backend-specific options

    Returns:
        Markdown string extracted from the document
    """
    input_path = Path(input_path)
    if not input_path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    # Detect input type
    suffix = input_path.suffix.lower()
    is_image = suffix in IMAGE_EXTENSIONS

    # Determine backend name for option building
    backend_name = backend
    if backend_name is None:
        preference = IMAGE_PREFERENCE if is_image else DEFAULT_PREFERENCE
        for name in preference:
            if name in BACKEND_REGISTRY and BACKEND_REGISTRY[name].is_available():
                if not is_image or name in IMAGE_CAPABLE_BACKENDS:
                    backend_name = name
                    break

    # Build merged options
    merged_options = _build_backend_options(
        backend_name or "docling",
        preset,
        ocr,
        backend_options,
    )

    # Get backend instance
    backend_instance = get_backend(backend, backend_options=merged_options, for_image=is_image)

    # Use async method if available, otherwise run sync in executor
    if hasattr(backend_instance, "parse_async"):
        return await backend_instance.parse_async(input_path)
    else:
        import asyncio

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, backend_instance.parse, input_path)
