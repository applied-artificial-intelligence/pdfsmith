"""
pdfsmith - PDF to Markdown conversion with multiple backend support.

A unified interface to 19 PDF/image parsing backends. Pick the right tool for the job,
or let pdfsmith choose for you.

Basic usage:
    from pdfsmith import parse

    # Auto-select best available backend
    markdown = parse("document.pdf")

    # Use specific backend
    markdown = parse("document.pdf", backend="docling")

    # Use quality preset
    markdown = parse("document.pdf", preset="best")

    # Enable OCR with language
    markdown = parse("scan.pdf", ocr="eng+deu")

    # Backend-specific options
    markdown = parse("document.pdf", backend="docling",
                    backend_options={"do_table_structure": True})

    # Parse images (auto-selects image-capable backend)
    markdown = parse("scan.png")

    # List available backends
    from pdfsmith import available_backends
    print(available_backends())
"""

from pdfsmith.api import (
    IMAGE_CAPABLE_BACKENDS,
    PRESETS,
    BackendName,
    PresetName,
    available_backends,
    get_backend,
    parse,
    parse_async,
)

__version__ = "0.3.0"
__all__ = [
    "parse",
    "parse_async",
    "available_backends",
    "get_backend",
    "BackendName",
    "PresetName",
    "PRESETS",
    "IMAGE_CAPABLE_BACKENDS",
    "__version__",
]
