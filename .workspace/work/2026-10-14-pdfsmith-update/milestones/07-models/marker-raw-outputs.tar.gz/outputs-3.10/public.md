**The Summary of Benefits and Coverage (SBC) document will help you choose a health plan. The SBC shows you how you and the plan would share the cost for covered health care services. NOTE: Information about the cost of this plan (called the premium) will be provided separately. This is only a summary.** For more information about your coverage, or to get a copy of the complete terms of coverage, call 1-800-809- 9361 (TTY: 711) or visit us at [https://www.premera.com/ak/SBC.](https://www.premera.com/ak/SBC) For general definitions of common terms, such as allowed amount, balance billing, coinsurance, copayment, deductible, Provider, or other underlined terms see the Glossary. You can view the Glossary at<https://www.healthcare.gov/sbc-glossary/> or call 1-800- 809-9361 (TTY: 711) to request a copy.

| Important Questions Answers Why This Matters:                         |                                                                           |
|-----------------------------------------------------------------------|---------------------------------------------------------------------------|
| Generally, you must pay all of the costs from providers               | up to the deductible amount                                               |
| before this plan                                                      | begins to pay. If you have other family members on the plan, each         |
| family member must meet their own individual deductible               | until the total amount of                                                 |
| deductible                                                            | expenses paid by all family members meets the overall family deductible.  |
| certain prescription drugs and services                               |                                                                           |
| This plan                                                             | covers some items and services even if you haven’t yet met the deductible |
| amount. But a copayment                                               | or coinsurance may apply. For example, this plan covers                   |
| certain preventive services without cost-sharing                      | and before you meet your                                                  |
| Are there other deductibles for                                       |                                                                           |
| specific services? No. You don’t have to meet deductibles             | for specific services.                                                    |
| The out-of-pocket limit                                               | is the most you could pay in a year for covered services. If              |
| pocket limits until the overall family out-of-pocket limit            | has been met.                                                             |
| Premium, balance-billed charges,                                      |                                                                           |
| authorization for services, and health care                           |                                                                           |
| providers, see https://www.premera.com                                |                                                                           |
| You pay the least if you use a provider                               | in our preferred network. You pay more if                                 |
| you use a provider                                                    | in our non-preferred network. You will pay the most if you use an         |
| out-of-network provider, and you might receive a bill from a provider | for the                                                                   |
| difference between the provider’s                                     | charge and what your plan pays (balance                                   |
| billing).Be aware your network provider                               | might use an out-of-network provider for                                  |
| some services (such as lab work). Check with your provider            | before you get services.                                                  |
| specialist? No. You can see the specialist                            | you choose without a referral.                                            |

| Medical Event Services You May Need |                                                                                           |
|-------------------------------------|-------------------------------------------------------------------------------------------|
| (You will pay the least)            | What You Will Pay Limitations, Exceptions, & Other Network Provider Important Information |
| care provider’s office              |                                                                                           |
| First two visits: \$1 copay         | /                                                                                         |
| visit, deductible                   | does not                                                                                  |
| apply.                              | Additional visits: \$30                                                                   |
| copay                               | / visit, deductible                                                                       |
|                                     | Non-Participating: 60% coinsurance –––––––––––none–––––––––––                             |
| Specialist visit \$60 copay         | / visit,                                                                                  |
| deductible                          | does not apply. Non-Participating: 60% coinsurance –––––––––––none–––––––––––             |
| Preventive care / screening         |                                                                                           |
| / immunization No charge            | Non-Participating: 60% coinsurance                                                        |
|                                     | aren’t preventive. Ask your provider if                                                   |
|                                     | Then check what your plan will pay for.                                                   |
| Diagnostic test (x-ray,             |                                                                                           |
|                                     | Non-Participating: 60% coinsurance –––––––––––none–––––––––––                             |
|                                     | Prior authorization required for some                                                     |
| coverage is available at            |                                                                                           |
| \$15 copay                          | / prescription                                                                            |
| \$45 copay                          | / prescription                                                                            |
| Deductible                          | does not apply.                                                                           |
|                                     | \$15 copay / prescription (retail)                                                        |
|                                     | Deductible does not apply.                                                                |
| \$45 copay                          | / prescription                                                                            |
| \$135 copay                         | / prescription                                                                            |
| Deductible                          | does not apply.                                                                           |
|                                     | \$45 copay / prescription (retail)                                                        |
|                                     | Deductible does not apply.                                                                |

| Medical Event Services You May Need |                           |                                                                     |                                       |
|-------------------------------------|---------------------------|---------------------------------------------------------------------|---------------------------------------|
|                                     | (You will pay the least)  | What You Will Pay Limitations, Exceptions, & Other Network Provider | Important Information                 |
| Non-preferred brand drugs           | 50% coinsurance           | 50% coinsurance (retail)                                            |                                       |
| Specialty drugs                     | 40% coinsurance           | 40% coinsurance                                                     |                                       |
|                                     |                           |                                                                     | Prior authorization required for some |
|                                     |                           | Non-Participating: 60% coinsurance                                  | –––––––––––none–––––––––––            |
| Emergency room care                 | 30% coinsurance           | 30% coinsurance                                                     | –––––––––––none–––––––––––            |
| transportation                      | 30% coinsurance           | 30% coinsurance                                                     | –––––––––––none–––––––––––            |
|                                     | copay / visit, deductible |                                                                     |                                       |
|                                     |                           |                                                                     | Prior authorization required for all  |
|                                     |                           | Non-Participating: 60% coinsurance                                  | –––––––––––none–––––––––––            |

| Medical Event Services You May Need                                                                                |                    |
|--------------------------------------------------------------------------------------------------------------------|--------------------|
| What You Will Pay Limitations, Exceptions, & Other Network Provider Important Information (You will pay the least) |                    |
| Office Visit: \$60 copay /                                                                                         |                    |
| visit, deductible does not                                                                                         |                    |
| Non-Participating: 60% coinsurance –––––––––––none–––––––––––                                                      |                    |
| Prior authorization                                                                                                | required for all   |
| Office visits 30% coinsurance Non-Participating: 60% coinsurance                                                   |                    |
| Cost-sharing                                                                                                       | does not apply for |
| type of services, a coinsurance                                                                                    | may                |
| Cost-sharing                                                                                                       | does not apply for |
| type of services, a coinsurance                                                                                    | may                |
| Cost-sharing                                                                                                       | does not apply for |
| type of services, a coinsurance                                                                                    | may                |
| Prior authorization                                                                                                | is not required.   |
| recovering or have Home health care                                                                                |                    |
| Non-Participating: 60% coinsurance Limited to 130 visits per calendar year                                         |                    |

| Medical Event Services You May Need |                            |                                                                     |                                         |
|-------------------------------------|----------------------------|---------------------------------------------------------------------|-----------------------------------------|
|                                     | (You will pay the least)   | What You Will Pay Limitations, Exceptions, & Other Network Provider | Important Information                   |
|                                     | Outpatient: \$60 copay /   |                                                                     |                                         |
|                                     |                            |                                                                     | authorization required for all planned  |
|                                     | Outpatient: \$60 copay /   |                                                                     |                                         |
|                                     |                            |                                                                     | authorization required for all planned  |
|                                     |                            |                                                                     | Prior authorization required for all    |
|                                     |                            |                                                                     | Prior authorization required to buy     |
| Children's eye exam                 | \$30 copay / visit         |                                                                     |                                         |
|                                     | Deductible does not apply. |                                                                     |                                         |
|                                     |                            | \$30 copay / visit                                                  |                                         |
|                                     |                            | Deductible does not apply.                                          |                                         |
| Children's glasses                  | No charge                  | No charge                                                           | Frames and lenses limited to 1 pair per |
| Children's dental check-up          | No charge                  | 30% coinsurance                                                     | –––––––––––none–––––––––––              |

# **Excluded Services & Other Covered Services:**

### **Services Your Plan Generally Does NOT Cover (Check your policy or plan document for more information and a list of any other excluded services.)**

- Assisted fertility treatment
- Bariatric surgery
- Cosmetic surgery
- Dental care (Adult)
- Hearing aids
- Long-term care
- Private-duty nursing
- Routine eye care (Adult)
- Weight loss programs

## **Other Covered Services (Limitations may apply to these services. This isn't a complete list. Please see your plan document.)**

- Abortion
- Acupuncture
- Chiropractic care or other spinal manipulations
- Foot care
- Non-emergency care when traveling outside the U.S.

**Your Rights to Continue Coverage:** There are agencies that can help if you want to continue your coverage after it ends. The contact information for those agencies is: 1-907-269-7900 or 1-800-467-8725 for the state insurance department, or the insurer at 1-800-809-9361 or TTY 711. Other coverage options may be available to you too, including buying individual insurance coverage through the Health Insurance Marketplace. For more information about the Marketplace, visit [www.HealthCare.gov](http://www.healthcare.gov/) or call 1-800-318-2596.

**Your Grievance and Appeals Rights:** There are agencies that can help if you have a complaint against your plan for a denial of a claim. This complaint is called a grievance or appeal. For more information about your rights, look at the explanation of benefits you will receive for that medical claim. Your plan documents also provide complete information to submit a claim, appeal, or grievance for any reason to your plan. For more information about your rights, this notice, or assistance, contact: your plan at 1-800-809-9361, or the state insurance department at 1-907-269-7900 or 1-800-467-8725.

### **Does this plan provide Minimum Essential Coverage? Yes.**

Minimum Essential Coverage generally includes plans, health insurance available through the Marketplace or other individual market policies, Medicare, Medicaid, CHIP, TRICARE, and certain other coverage. If you are eligible for certain types of Minimum Essential Coverage, you may not be eligible for the premium tax credit.

### **Does this plan meet Minimum Value Standards? Not Applicable.**

If your plan doesn't meet the Minimum Value Standards, you may be eligible for a premium tax credit to help you pay for a plan through the Marketplace.

#### **Language Access Services:**

Spanish (Español): Para obtener asistencia en Español, llame al 1-800-809-9361 or TTY 711.

Tagalog (Tagalog): Kung kailangan ninyo ang tulong sa Tagalog tumawag sa 1-800-809-9361 or TTY 711.

Chinese (中文): 如果需要中文的帮助,请拨打这个号码1-800-809-9361 or TTY 711.

Navajo (Dine): Dinek'ehgo shika at'ohwol ninisingo, kwiijigo holne' 1-800-809-9361 or TTY 711.

–––––––––––––––––––*To see examples of how this plan might cover costs for a sample medical situation, see the next section.–––––––––––*–––––––

# **About these Coverage Examples:**

**This is not a cost estimator.** Treatments shown are just examples of how this plan might cover medical care. Your actual costs will be different depending on the actual care you receive, the prices your providers charge, and many other factors. Focus on the cost sharing amounts (deductibles, copayments and coinsurance) and excluded services under the plan. Use this information to compare the portion of costs you might pay under different health plans. Please note these coverage examples are based on self-only coverage.

.

# **Peg is Having a baby**

(9 months of in-network pre-natal care and a hospital delivery)

### **This EXAMPLE event includes services like:**

Specialist office visits (*prenatal care*) Childbirth/Delivery Professional Services Childbirth/Delivery Facility Services Diagnostic tests (*ultrasounds and blood work*) Specialist visit (*anesthesia*)

**Total Example Cost** \$12,700

### **In this example, Peg would pay:**

|                            | Cost Sharing               |
|----------------------------|----------------------------|
| Deductibles                | \$1,500                    |
| Copayments                 | \$10                       |
| Coinsurance                | \$3,300 What isn't covered |
| Limits or exclusions       | \$60                       |
| The Total Peg would pay is | \$4,870                    |

#### **Managing Joe's type 2 diabetes** (a year of routine in-network care of a wellcontrolled condition)

### **This EXAMPLE event includes services like:**

Primary care physician office visits (*including disease education*)

Diagnostic tests (*blood work*)

Prescription drugs

Durable medical equipment (*glucose meter*)

**Total Example Cost** \$5,600

# **In this example, Joe would pay:**

|                            | Cost Sharing           |
|----------------------------|------------------------|
| Deductibles                | \$200                  |
| Copayments                 | \$1,600                |
| Coinsurance                | \$0 What isn't covered |
| Limits or exclusions       | \$20                   |
| The Total Joe would pay is | \$1,820                |

# **Mia's Simple Fracture**

(in-network emergency room visit and follow up care)

## **This EXAMPLE event includes services like:**

Emergency room care (*including medical*

*supplies*)

Diagnostic test (*x-ray*)

Durable medical equipment (*crutches*) Rehabilitation services (*physical therapy*)

**Total Example Cost** \$2,800

## **In this example, Mia would pay:**

|                            | Cost Sharing             |
|----------------------------|--------------------------|
| Deductibles                | \$1,500                  |
| Copayments                 | \$300                    |
| Coinsurance                | \$300 What isn't covered |
| Limits or exclusions       | \$0                      |
| The Total Mia would pay is | \$2,100                  |

The **plan** would be responsible for the other costs of these EXAMPLE covered services.

Call for free language assistance services and appropriate auxiliary aids and services.

Tumawag para sa mga libreng serbisyo ng tulong sa wika at angkop na mga karagdagang tulong at serbisyo.

Llame para obtener servicios gratuitos de asistencia lingüística, y ayudas y servicios auxiliares apropiados.

무료 언어 지원 서비스와 적절한 보조 도구 및 서비스를 신청하십시오.

Hu thov kev pab txhais lus pub dawb thiab lwm yam khoom pab dawb thiab kev pab cuam ua tsim nyog.

Звоните для получения бесплатных услуг по переводу и других вспомогательных средств и услуг. 呼吁提供免费的语言援助服务和适当的辅助设备及服务。

呼籲提供免費的語言援助服務和適當的輔助設備及服務。

Valaʻau mo auaunaga tau fesoasoani mo gagana e leai ni totogi ma fesoasoani faʻaopoʻopo talafeagai ma auaunaga.

ໂທເພຼືື່ ອຮັບການບໍ ລິການຊື່ວຍເຫຼື ອດ້ານພາສາ ແລະ ການບໍ ລິ ການ ແລະ ການຊື່ວຍເຫຼື ອພິເສດທ ື່ ເໝາະສົມແບບບໍ 無料言語支援サービスと適切な補助器具及びサービスをお求めください。

ື່ ເສຍຄື່າ.

Tumawag para kadagiti libre a serbisio iti tulong iti pagsasao ken dagiti nakanada nga aid ken serbisio iti komunikasion.

Gọi cho các dịch vụ hỗ trợ ngôn ngữ miễn phí và các hỗ trợ và dịch vụ phụ trợ thích hợp.

Звертайтесь за безкоштовною мовною підтримкою та відповідними додатковими послугами.

ตดิ ตอ่ ขอบรกิ ารชว่ ยเหลอืดา้นภาษาฟรพี รอ้มความชว่ ยเหลอื และบรกิ ารอืน่ ๆ เพิม่ เตมิ

Fordern Sie kostenlose Sprachunterstützungsdienste und geeignete Hilfsmittel und Dienstleistungen an.

Zadzwoń, aby uzyskać bezpłatną pomoc językową oraz odpowiednie wsparcie i usługi pomocnicze.

Rele pou w jwenn sèvis asistans lengwistik gratis ak èd epi sèvis oksilyè ki apwopriye.

Appelez pour obtenir des services gratuits d'assistance linguistique et des aides et services auxiliaires appropriés.

Ligue para serviços gratuitos de assistência linguística e auxiliares e serviços auxiliares adequados.

Chiama per i servizi di assistenza linguistica gratuiti e per gli ausili e i servizi ausiliari appropriati.

اتصل للحصول على خدمات المساعدة اللغوية المجانية والمساعدات والخدمات المناسبة. برای خدمات کمک زبانی رايگان و کمکها و خدمات امدادی مقتضی، تماس بگيريد .

**Discrimination is against the law.** Premera Blue Cross Blue Shield of Alaska (Premera) complies with applicable Federal civil rights laws and does not discriminate on the basis of race, color, national origin, age, disability, or sex, including sex characteristics, intersex traits, pregnancy or related conditions, sexual orientation, gender identity, and sex stereotypes. Premera does not exclude people or treat them less favorably because of race, color, national origin, age, disability, or sex. Premera provides people with disabilities reasonable modifications and free appropriate auxiliary aids and services to communicate effectively with us, such as qualified sign language interpreters and written information in other formats (large print, audio, accessible electronic formats, other formats). Premera provides free language assistance services to people whose primary language is not English, which may include qualified interpreters and information written in other languages. If you need reasonable modifications, appropriate auxiliary aids and services, or language assistance services, contact our Civil Rights Coordinator. If you believe that Premera has failed to provide these services or discriminated in another way on the basis of race, color, national origin, age, disability, or sex, you can file a grievance with: Civil Rights Coordinator ─ Complaints and Appeals, PO Box 91102, Seattle, WA 98111, Toll free: 855-332-4535, TTY: 711, Fax: 425-918-5592, Email [AppealsDepartmentInquiries@Premera.com.](mailto:AppealsDepartmentInquiries@Premera.com) You can file a grievance in person or by mail, fax, or email. If you need help filing a grievance, our Civil Rights Coordinator is available to help you. You can also file a civil rights complaint with the U.S. Department of Health and Human Services, Office for Civil Rights, electronically through the Office for Civil Rights Complaint Portal, available at [https://ocrportal.hhs.gov/ocr/portal/lobby.jsf,](https://ocrportal.hhs.gov/ocr/portal/lobby.jsf) or by mail or phone at: U.S. Department of Health and Human Services, 200 Independence Ave SW, Room 509F, HHH Building, Washington, D.C. 20201, 1-800-368-1019, 800-537-7697 (TDD). Complaint forms are available at [http://www.hhs.gov/ocr/office/file/index.html.](http://www.hhs.gov/ocr/office/file/index.html)