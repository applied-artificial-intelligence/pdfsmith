from pathlib import Path
from docling.utils.model_downloader import download_models
path = download_models(output_dir=Path(__file__).parent / "assets/docling", with_layout=True, with_tableformer=True, with_code_formula=False, with_picture_classifier=False, with_rapidocr=False)
print(path)
