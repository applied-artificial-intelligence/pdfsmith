from pathlib import Path
import json,socket
from unittest.mock import patch
from pdfsmith import parse
from docling.backend.docling_parse_backend import ThreadedDoclingParsePageBackend
from docling.document_converter import DocumentConverter
original_convert=DocumentConverter.convert
sdk_results=[]
def capture(self,*a,**kw):
    result=original_convert(self,*a,**kw)
    sdk_results.append(dict(status=result.status.value, errors=len(result.errors), pages=len(result.pages)))
    return result
DocumentConverter.convert=capture

def denied(*a,**k):raise RuntimeError("Network disabled during conversion")
socket.create_connection=denied;socket.getaddrinfo=denied;socket.socket.connect=denied
path=Path(__file__).parent/"local-fixtures/two-pages.pdf"
original=ThreadedDoclingParsePageBackend.is_valid
def fail_second(self):
    if self.page_no==2:return False
    return original(self)
records=[]
for mode in ["normal","second-page-failure"]:
    try:
        with patch.object(ThreadedDoclingParsePageBackend,"is_valid",fail_second if mode!="normal" else original):
            text=parse(path,backend="docling",backend_options={"device":"cpu","num_threads":2})
        records.append(dict(mode=mode,returned_text=text,sdk_result=sdk_results[-1]))
    except Exception as exc:records.append(dict(mode=mode,error_type=type(exc).__name__,error=str(exc)))
output=Path(__file__).parent.parent/"milestones/07-models/docling-conversion-before.json"
output.write_text(json.dumps(records,indent=2)+"\n")
print(json.dumps(records,indent=2))
