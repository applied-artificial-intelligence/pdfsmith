from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,os,json,hashlib,tarfile
w=Path(__file__).parent.parent;r=w/'runtime';m=w/'milestones/07-models';wheel=r/'wheels/pdfsmith-0.3.0.dev0-py3-none-any.whl'
env={k:v for k,v in os.environ.items() if k in {'PATH','LANG'}}
env.update(HOME=str(r/'home'),HF_HOME=str(r/'assets/huggingface'),HF_HUB_OFFLINE='1',_PDFSMITH_TEST_OFFLINE='1',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(r/'tmp'),HTTP_PROXY='http://127.0.0.1:9',HTTPS_PROXY='http://127.0.0.1:9',ALL_PROXY='http://127.0.0.1:9',NO_PROXY='',no_proxy='')
def run(py):
 target=r/f'local-marker-{py}';subprocess.run(['uv','venv','--clear','--python',py,str(target)],capture_output=True,check=True)
 install=['uv','pip','install','--python',str(target/'bin/python'),'--torch-backend','cpu',str(wheel)+'[marker]']
 p=subprocess.run(install,capture_output=True,text=True,timeout=300);(m/f'install-marker-{py}.txt').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stdout+p.stderr
 output=r/f'marker-outputs-{py}'
 cmd=[str(target/'bin/python'),'-I',str(w/'milestones/marker_probe.py'),'--document','/home/stefan/agents/document-evidence/data/raw/AK_38344_38344AK1060001-01.pdf','--fixtures',str(r/'local-fixtures'),'--assets',str(r/'assets/marker'),'--binary',str(r/'assets/marker/llamacpp/llama-b11669/llama-server'),'--output',str(output)]
 p=subprocess.run(cmd,cwd=r/'model-inspection',env=env,capture_output=True,text=True,timeout=1800);(m/f'run-marker-{py}.txt').write_text(('Command: '+repr(cmd)+'\nExit: '+str(p.returncode)+'\n'+p.stdout+p.stderr).rstrip()+'\n');assert p.returncode==0,p.stdout+p.stderr
 result=json.loads((output/'result.json').read_text());result.update(command=cmd,install_command=install,wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest());(m/f'installed-marker-{py}.json').write_text(json.dumps(result,indent=2)+'\n');print(py,'Marker installed E2E passed',flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,['3.10','3.11','3.12','3.13']))
with tarfile.open(m/'marker-raw-outputs.tar.gz','w:gz') as a:
 for py in ['3.10','3.11','3.12','3.13']:a.add(r/f'marker-outputs-{py}',arcname=f'outputs-{py}')
 a.add(r/'local-fixtures',arcname='fixtures')
