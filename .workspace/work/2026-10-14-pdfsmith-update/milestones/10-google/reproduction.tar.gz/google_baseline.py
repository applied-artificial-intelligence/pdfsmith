from pathlib import Path
import json,os,socket,tarfile,hashlib
from unittest.mock import patch
from tests.google_transport import google_clients
from google.cloud import documentai_v1 as d
from pdfsmith import parse
from pdfsmith.backends.google_document_ai_backend import GoogleDocumentAIBackend
w=Path('.workspace/work/2026-10-14-pdfsmith-update');m=w/'milestones/10-google';source=Path('src/pdfsmith/backends/google_document_ai_backend.py')
with tarfile.open(m/'inherited-source.tar.gz','w:gz') as a:a.add(source,arcname=source.name)
(m/'inherited-sha256.txt').write_text(hashlib.sha256(source.read_bytes()).hexdigest()+'\n')
def deny(*a,**kw):raise RuntimeError('No network in Google baseline')
socket.socket.connect=deny;socket.getaddrinfo=deny
os.environ.update(GOOGLE_APPLICATION_CREDENTIALS='unused-offline.json',GOOGLE_CLOUD_PROJECT='offline',GOOGLE_DOCUMENT_AI_PROCESSOR_ID='processor')
results=[]
for case in ['complete','document-error','missing-pages']:
 client,storage,wire=google_clients(case)
 with patch.object(d,'DocumentProcessorServiceClient',return_value=client):
  try:result={'returned':parse(w/'runtime/ocr-fixtures/two-pages.pdf',backend='google_document_ai')}
  except Exception as e:result={'error_type':type(e).__name__,'error':str(e)}
 results.append(dict(case=case,result=result,client_close_calls=wire.closed,calls=wire.calls))
(m/'before.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
