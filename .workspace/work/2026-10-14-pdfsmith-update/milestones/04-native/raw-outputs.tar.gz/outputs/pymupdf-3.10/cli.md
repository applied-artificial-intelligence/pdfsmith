Summary of Benefits and Coverage: What this Plan Covers & What You Pay for Covered Services Coverage Period: 1/1/2025 -12/31/2025
Premera Blue Cross Blue Shield of Alaska: Preferred Gold 1500 Coverage for: Individual or Family | Plan Type: PPO
The Summary of Benefits and Coverage (SBC) document will help you choose a health plan. The SBC shows you how you and the plan would
share the cost for covered health care services. NOTE: Information about the cost of this plan (called the premium) will be provided
separately. This is only a summary. For more information about your coverage, or to get a copy of the complete terms of coverage, call 1-800-809-
9361 (TTY: 711) or visit us at https://www.premera.com/ak/SBC. For general definitions of common terms, such as allowed amount, balance billing, coinsurance,
copayment, deductible, Provider, or other underlined terms see the Glossary. You can view the Glossary at https://www.healthcare.gov/sbc-glossary/ or call 1-800-
809-9361 (TTY: 711) to request a copy.

Important Questions Answers Why This Matters:
Generally, you must pay all of the costs from providers up to the deductible amount In-network: $1,500 Individual / $3,000 What is the overall before this plan begins to pay. If you have other family members on the plan, each Family deductible? family member must meet their own individual deductible until the total amount of Out-of-network: $4,500 Individual deductible expenses paid by all family members meets the overall family deductible.
This plan covers some items and services even if you haven’t yet met the deductible
Are there services covered Yes. Does not apply to copayments, amount. But a copayment or coinsurance may apply. For example, this plan covers
before you meet your certain prescription drugs and services certain preventive services without cost-sharing and before you meet your
deductible? listed below as "No charge." deductible. See a list of covered preventive services at
https://www.healthcare.gov/coverage/ preventive-care-benefits/.
Are there other deductibles for No. You don’t have to meet deductibles for specific services. specific services?
In-network: $6,300 Individual / $12,600 The out-of-pocket limit is the most you could pay in a year for covered services. If What is the out-of-pocket limit Family you have other family members in this plan, they have to meet their own out-of- for this plan? Out-of-network: Not Applicable pocket limits until the overall family out-of-pocket limit has been met.
Premium, balance-billed charges,
What is not included in the penalties for failure to obtain prior Even though you pay these expenses, they don’t count toward the out-of-pocket
out-of-pocket limit? authorization for services, and health care limit.
this plan doesn't cover.
You pay the least if you use a provider in our preferred network. You pay more if
Yes. See Legacy and Dental Select you use a provider in our non-preferred network. You will pay the most if you use an
Will you pay less if you use a medical network. For a list of in-network out-of-network provider, and you might receive a bill from a provider for the
network provider? providers, see https://www.premera.com difference between the provider’s charge and what your plan pays (balance
or call 1-800-809-9361. billing).Be aware your network provider might use an out-of-network provider for
some services (such as lab work). Check with your provider before you get services.
Do you need a referral to see a No. You can see the specialist you choose without a referral. specialist?

1 of 7

All copayment and coinsurance costs shown in this chart are after your overall deductible has been met, if a deductible applies.

What You Will Pay
Common Limitations, Exceptions, & Other Services You May Need Network Provider Out-Of-Network ProviderMedical Event Important Information
(You will pay the least) (You will pay the most)
First two visits: $1 copay /
visit, deductible does not Primary care visit to treat apply. Additional visits: $30 Non-Participating: 60% coinsurance –––––––––––none––––––––––– an injury or illness copay / visit, deductible
If you visit a health does not apply.
care provider’s office $60 copay / visit, Specialist visit Non-Participating: 60% coinsurance –––––––––––none–––––––––––or clinic deductible does not apply.
You may have to pay for services that
Preventive care / screening aren’t preventive. Ask your provider if No charge Non-Participating: 60% coinsurance / immunization the services needed are preventive.
Then check what your plan will pay for.
Preferred: 30% Diagnostic test (x-ray, coinsurance. Participating: Non-Participating: 60% coinsurance –––––––––––none––––––––––– blood work) 40% coinsurance
If you have a test Prior authorization required for some Preferred: 30% Imaging (CT/PET scans, outpatient imaging tests. The penalty coinsurance. Participating: Non-Participating: 60% coinsurance MRIs) is: 50% of the allowable charge up to a 40% coinsurance maximum of $1,500 per occurrence.
$15 copay / prescription Covers up to a 30 day supply (retail),
If you need drugs to (retail) $15 copay / prescription (retail) covers up to a 90 day supply (mail). No
treat your illness or Preferred generic drugs $45 copay / prescription Not covered (mail) charge for specific preventive drugs.
condition (mail) Deductible does not apply. Prior authorization required for some
Deductible does not apply. drugs.
More information about $45 copay / prescription Covers up to a 30 day supply (retail),prescription drug (retail) $45 copay / prescription (retail) covers up to a 90 day supply (mail). Nocoverage is available at Preferred brand drugs $135 copay / prescription Not covered (mail) charge for specific preventive drugs.https://www.premera.co (mail) Deductible does not apply. Prior authorization required for somem/documents/062279_2 Deductible does not apply. drugs.

2 of 7

What You Will Pay
Common Limitations, Exceptions, & Other Services You May Need Network Provider Out-Of-Network ProviderMedical Event Important Information
(You will pay the least) (You will pay the most)
025.pdf. Covers up to a 30 day supply (retail),
covers up to a 90 day supply (mail). No 50% coinsurance (retail) Non-preferred brand drugs 50% coinsurance charge for specific preventive drugs. Not covered (mail) Prior authorization required for some
drugs.
Covers up to a 30 day supply. Only
covered at specific contracted specialty Specialty drugs 40% coinsurance 40% coinsurance pharmacies. Prior authorization
required for some drugs.
Prior authorization required for some Preferred: 30% Facility fee (e.g., services. The penalty is: 50% of the coinsurance. Participating: Non-Participating: 60% coinsurance ambulatory surgery center) allowable charge up to a maximum ofIf you have outpatient 40% coinsurance $1,500 per occurrence.surgery Preferred: 30%
Physician/surgeon fees coinsurance. Participating: Non-Participating: 60% coinsurance –––––––––––none–––––––––––
40% coinsurance
Emergency room care 30% coinsurance 30% coinsurance –––––––––––none–––––––––––
Emergency medical 30% coinsurance 30% coinsurance –––––––––––none––––––––––– transportation
If you need immediate Hospital-based: 30%medical attention coinsurance Hospital-based: 30% coinsurance
Urgent care Freestanding center: $60 Freestanding center: Non- –––––––––––none–––––––––––
copay / visit, deductible Participating: 60% coinsurance
does not apply.
Prior authorization required for all Preferred: 30% Facility fee (e.g., hospital planned inpatient stays. The penalty is: coinsurance. Participating: Non-Participating: 60% coinsurance room) 50% of the allowable charge up to aIf you have a hospital 40% coinsurance maximum of $1,500 per occurrence.stay Preferred: 30%
Physician/surgeon fees coinsurance. Participating: Non-Participating: 60% coinsurance –––––––––––none–––––––––––
40% coinsurance

3 of 7

What You Will Pay
Common Limitations, Exceptions, & Other Services You May Need Network Provider Out-Of-Network ProviderMedical Event Important Information
(You will pay the least) (You will pay the most)
Office Visit: $60 copay /
visit, deductible does not
apply. Outpatient services Non-Participating: 60% coinsurance –––––––––––none–––––––––––If you need mental Facility: Preferred: 30%
health, behavioral coinsurance. Participating:
health, or substance 40% coinsurance
abuse services Prior authorization required for all Preferred: 30% planned inpatient stays. The penalty is: Inpatient services coinsurance. Participating: Non-Participating: 60% coinsurance 50% of the allowable charge up to a 40% coinsurance maximum of $1,500 per occurrence.
Cost-sharing does not apply for
preventive services. Depending on the
type of services, a coinsurance may Office visits 30% coinsurance Non-Participating: 60% coinsurance apply. Maternity care may include tests
and services described elsewhere in
the SBC (such as, ultrasound).
Cost-sharing does not apply for
Preferred: 30% preventive services. Depending on the
Childbirth/delivery coinsurance. type of services, a coinsurance may Non-Participating: 60% coinsurance professional services Participating: 40% apply. Maternity care may include tests
coinsurance and services described elsewhere inIf you are pregnant the SBC (such as, ultrasound).
Cost-sharing does not apply for
preventive services. Depending on the
type of services, a coinsurance may
Preferred: 30% apply. Maternity care may include tests
Childbirth/delivery facility coinsurance. and services described elsewhere in Non-Participating: 60% coinsurance services Participating: 40% the SBC (such as, ultrasound).
coinsurance Prior authorization is not required.
However, you should notify the carrier
of your admission for delivery as soon
as reasonably possible.
Preferred: 30%If you need help Home health care coinsurance. Participating: Non-Participating: 60% coinsurance Limited to 130 visits per calendar yearrecovering or have 40% coinsurance

4 of 7

What You Will Pay
Common Limitations, Exceptions, & Other Services You May Need Network Provider Out-Of-Network ProviderMedical Event Important Information
(You will pay the least) (You will pay the most)
other special health Limited to 45 outpatient visits per
needs Outpatient: $60 copay / calendar year, limited to 30 inpatient
visit days per calendar year. Prior
Rehabilitation services Inpatient: Preferred: 30% Non-Participating: 60% coinsurance authorization required for all planned
coinsurance. Participating: inpatient stays. The penalty is: 50% of
40% coinsurance the allowable charge up to a maximum
of $1,500 per occurrence.
Limited to 45 outpatient visits per
Outpatient: $60 copay / calendar year, limited to 30 inpatient
visit days per calendar year. Prior
Habilitation services Inpatient: Preferred: 30% Non-Participating: 60% coinsurance authorization required for all planned
coinsurance. Participating: inpatient stays. The penalty is: 50% of
40% coinsurance the allowable charge up to a maximum
of $1,500 per occurrence.
Limited to 60 days per calendar year.
Preferred: 30% Prior authorization required for all
Skilled nursing care coinsurance. Participating: Non-Participating: 60% coinsurance planned inpatient stays. The penalty is:
40% coinsurance 50% of the allowable charge up to a
maximum of $1,500 per occurrence.
Prior authorization required to buy
Preferred: 30% some medical equipment over $750.
Durable medical equipment coinsurance. Participating: Non-Participating: 60% coinsurance The penalty is: 50% of the allowable
40% coinsurance charge up to a maximum of $1,500 per
occurrence.
Preferred: 30% Limited to 240 respite hours, limited to
Hospice service coinsurance. Participating: Non-Participating: 60% coinsurance 10 inpatient days – 6 months overall
40% coinsurance lifetime benefit limit.
$30 copay / visit $30 copay / visit Limited to one exam per calendar year Children's eye exam Deductible does not apply. Deductible does not apply. (under age 19).
If your child needs Frames and lenses limited to 1 pair per Children's glasses No charge No chargedental or eye care calendar year.
Children's dental check-up No charge 30% coinsurance –––––––––––none–––––––––––

5 of 7

Excluded Services & Other Covered Services:
Services Your Plan Generally Does NOT Cover (Check your policy or plan document for more information and a list of any other excluded services.)
• Assisted fertility treatment • Dental care (Adult) • Private-duty nursing
• Bariatric surgery • Hearing aids • Routine eye care (Adult)
• Cosmetic surgery • Long-term care • Weight loss programs
Other Covered Services (Limitations may apply to these services. This isn’t a complete list. Please see your plan document.)
• Abortion • Chiropractic care or other spinal • Foot care
• Acupuncture manipulations • Non-emergency care when traveling outside the U.S.
Your Rights to Continue Coverage: There are agencies that can help if you want to continue your coverage after it ends. The contact information for those
agencies is: 1-907-269-7900 or 1-800-467-8725 for the state insurance department, or the insurer at 1-800-809-9361 or TTY 711. Other coverage options may be
available to you too, including buying individual insurance coverage through the Health Insurance Marketplace. For more information about the Marketplace, visit
www.HealthCare.gov or call 1-800-318-2596.
Your Grievance and Appeals Rights: There are agencies that can help if you have a complaint against your plan for a denial of a claim. This complaint is called a
grievance or appeal. For more information about your rights, look at the explanation of benefits you will receive for that medical claim. Your plan documents also
provide complete information to submit a claim, appeal, or grievance for any reason to your plan. For more information about your rights, this notice, or assistance,
contact: your plan at 1-800-809-9361, or the state insurance department at 1-907-269-7900 or 1-800-467-8725.
Does this plan provide Minimum Essential Coverage? Yes.
Minimum Essential Coverage generally includes plans, health insurance available through the Marketplace or other individual market policies, Medicare, Medicaid,
CHIP, TRICARE, and certain other coverage. If you are eligible for certain types of Minimum Essential Coverage, you may not be eligible for the premium tax credit.
Does this plan meet Minimum Value Standards? Not Applicable.
If your plan doesn’t meet the Minimum Value Standards, you may be eligible for a premium tax credit to help you pay for a plan through the Marketplace.
Language Access Services:
Spanish (Español): Para obtener asistencia en Español, llame al 1-800-809-9361 or TTY 711.
Tagalog (Tagalog): Kung kailangan ninyo ang tulong sa Tagalog tumawag sa 1-800-809-9361 or TTY 711.
Chinese (中文): 如果需要中文的帮助，请拨打这个号码1-800-809-9361 or TTY 711.
Navajo (Dine): Dinek'ehgo shika at'ohwol ninisingo, kwiijigo holne' 1-800-809-9361 or TTY 711.
–––––––––––––––––––To see examples of how this plan might cover costs for a sample medical situation, see the next section.––––––––––––––––––

6 of 7

About these Coverage Examples:
This is not a cost estimator. Treatments shown are just examples of how this plan might cover medical care. Your actual costs will be different
depending on the actual care you receive, the prices your providers charge, and many other factors. Focus on the cost sharing amounts (deductibles,
copayments and coinsurance) and excluded services under the plan. Use this information to compare the portion of costs you might pay under
different health plans. Please note these coverage examples are based on self-only coverage.
.
Peg is Having a baby Managing Joe's type 2 diabetes Mia's Simple Fracture
(9 months of in-network pre-natal care and a (a year of routine in-network care of a well- (in-network emergency room visit and follow up
hospital delivery) controlled condition) care)
 The plan's overall deductible $1,500  The plan's overall deductible $1,500  The plan's overall deductible $1,500
 Specialist copay $60  Specialist copay $60  Specialist copay $60
 Hospital (facility) coinsurance 30%  Hospital (facility) coinsurance 30%  Hospital (facility) coinsurance 30%
 Other coinsurance 30%  Other coinsurance 30%  Other coinsurance 30%
This EXAMPLE event includes services like: This EXAMPLE event includes services like: This EXAMPLE event includes services like:
Specialist office visits (prenatal care) Primary care physician office visits (including disease Emergency room care (including medical
Childbirth/Delivery Professional Services education) supplies)
Childbirth/Delivery Facility Services Diagnostic tests (blood work) Diagnostic test (x-ray)
Diagnostic tests (ultrasounds and blood work) Prescription drugs Durable medical equipment (crutches)
Specialist visit (anesthesia) Durable medical equipment (glucose meter) Rehabilitation services (physical therapy)
Total Example Cost $12,700 Total Example Cost $5,600 Total Example Cost $2,800
In this example, Peg would pay: In this example, Joe would pay: In this example, Mia would pay:
Cost Sharing Cost Sharing Cost Sharing
Deductibles $1,500 Deductibles $200 Deductibles $1,500
Copayments $10 Copayments $1,600 Copayments $300
Coinsurance $3,300 Coinsurance $0 Coinsurance $300
What isn't covered What isn't covered What isn't covered
Limits or exclusions $60 Limits or exclusions $20 Limits or exclusions $0
The Total Peg would pay is $4,870 The Total Joe would pay is $1,820 The Total Mia would pay is $2,100

The plan would be responsible for the other costs of these EXAMPLE covered services.

045632 (08-01-2024) Premera Blue Cross is an Independent Licensee of the Blue Cross Blue Shield Association MET-INDIV-WA 38344AK1060001-01
7 of 7

Notice of availability and nondiscrimination 800-809-9361 | TTY: 711

Call for free language assistance services and appropriate auxiliary aids and services.
Tumawag para sa mga libreng serbisyo ng tulong sa wika at angkop na mga karagdagang tulong at serbisyo.
Llame para obtener servicios gratuitos de asistencia lingüística, y ayudas y servicios auxiliares apropiados.
무료 언어 지원 서비스와 적절한 보조 도구 및 서비스를 신청하십시오.
Hu thov kev pab txhais lus pub dawb thiab lwm yam khoom pab dawb thiab kev pab cuam ua tsim nyog.
Звоните для получения бесплатных услуг по переводу и других вспомогательных средств и услуг.
呼吁提供免费的语言援助服务和适当的辅助设备及服务。
呼籲提供免費的語言援助服務和適當的輔助設備及服務。
Valaʻau mo auaunaga tau fesoasoani mo gagana e leai ni totogi ma fesoasoani faʻaopoʻopo talafeagai ma auaunaga.
ໂທເພຼືື່ອຮັບການບໍລິການຊື່ວຍເຫຼືອດ້ານພາສາ ແລະ ການບໍລິການ ແລະ ການຊື່ວຍເຫຼືອພິເສດທື່ເໝາະສົມແບບບໍື່ເສຍຄື່າ.
無料言語支援サービスと適切な補助器具及びサービスをお求めください。
Tumawag para kadagiti libre a serbisio iti tulong iti pagsasao ken dagiti nakanada nga aid ken serbisio iti komunikasion.
Gọi cho các dịch vụ hỗ trợ ngôn ngữ miễn phí và các hỗ trợ và dịch vụ phụ trợ thích hợp.
Звертайтесь за безкоштовною мовною підтримкою та відповідними додатковими послугами.
ติดต่อขอบริการช่วยเหลือด้านภาษาฟรีพร้อมความช่วยเหลือและบริการอื่น ๆ เพิ่มเติม
Fordern Sie kostenlose Sprachunterstützungsdienste und geeignete Hilfsmittel und Dienstleistungen an.
Zadzwoń, aby uzyskać bezpłatną pomoc językową oraz odpowiednie wsparcie i usługi pomocnicze.
Rele pou w jwenn sèvis asistans lengwistik gratis ak èd epi sèvis oksilyè ki apwopriye.
Appelez pour obtenir des services gratuits d’assistance linguistique et des aides et services auxiliaires appropriés.
Ligue para serviços gratuitos de assistência linguística e auxiliares e serviços auxiliares adequados.
Chiama per i servizi di assistenza linguistica gratuiti e per gli ausili e i servizi ausiliari appropriati.
.المناسبة والخدمات والمساعدات المجانية اللغوية المساعدة خدمات على للحصول اتصل
.بگيريد تماس ،مقتضی امدادی خدمات و هاکمک و رايگان زبانی کمک خدمات برای

Discrimination is against the law. Premera Blue Cross Blue Shield of Alaska (Premera) complies with applicable Federal
civil rights laws and does not discriminate on the basis of race, color, national origin, age, disability, or sex, including sex
characteristics, intersex traits, pregnancy or related conditions, sexual orientation, gender identity, and sex stereotypes.
Premera does not exclude people or treat them less favorably because of race, color, national origin, age, disability, or sex.
Premera provides people with disabilities reasonable modifications and free appropriate auxiliary aids and services to
communicate effectively with us, such as qualified sign language interpreters and written information in other formats (large
print, audio, accessible electronic formats, other formats). Premera provides free language assistance services to people
whose primary language is not English, which may include qualified interpreters and information written in other languages.
If you need reasonable modifications, appropriate auxiliary aids and services, or language assistance services, contact our
Civil Rights Coordinator. If you believe that Premera has failed to provide these services or discriminated in another way on
the basis of race, color, national origin, age, disability, or sex, you can file a grievance with: Civil Rights Coordinator ─
Complaints and Appeals, PO Box 91102, Seattle, WA 98111, Toll free: 855-332-4535, TTY: 711, Fax: 425-918-5592,
Email AppealsDepartmentInquiries@Premera.com. You can file a grievance in person or by mail, fax, or email. If you need
help filing a grievance, our Civil Rights Coordinator is available to help you. You can also file a civil rights complaint with the
U.S. Department of Health and Human Services, Office for Civil Rights, electronically through the Office for Civil Rights
Complaint Portal, available at https://ocrportal.hhs.gov/ocr/portal/lobby.jsf, or by mail or phone at: U.S. Department of Health
and Human Services, 200 Independence Ave SW, Room 509F, HHH Building, Washington, D.C. 20201, 1-800-368-1019,
800-537-7697 (TDD). Complaint forms are available at http://www.hhs.gov/ocr/office/file/index.html.

An Independent Licensee of the Blue Cross Blue Shield Association
051269 (07-05-2024)