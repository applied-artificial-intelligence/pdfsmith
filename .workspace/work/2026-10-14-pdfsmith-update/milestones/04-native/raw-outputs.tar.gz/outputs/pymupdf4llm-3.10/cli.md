**Summary of Benefits and Coverage:** What this Plan Covers & What You Pay for Covered Services **Premera Blue Cross Blue Shield of Alaska: Preferred Gold 1500** 

**Coverage Period: 1/1/2025 -12/31/2025 Coverage for: Individual or Family | Plan Type: PPO** 

**The Summary of Benefits and Coverage (SBC) document will help you choose a health plan. The SBC shows you how you and the plan would share the cost for covered health care services. NOTE: Information about the cost of this plan (called the premium) will be provided separately. This is only a summary.** For more information about your coverage, or to get a copy of the complete terms of coverage, call 1-800-8099361 (TTY: 711) or visit us at https://www.premera.com/ak/SBC. For general definitions of common terms, such as allowed amount, <u>balance billing, coinsurance, copayment, deductible, Provider, or other underlined terms see the Glossary. You can view the Glossary at https://www.healthcare.gov/sbc-glossary/</u> or call 1-800- <u>809-9361 (TTY: 711) to request a copy.</u> 

|**ImportantQuestions**|**Answers**|**Why This Matters:**|
|---|---|---|
|**What is the overall**<br>**deductible?**|In-network: $1,500 Individual / $3,000<br>Family<br>Out-of-network: $4,500 Individual|Generally, you must pay all of the costs fromprovidersup to thedeductibleamount<br>before thisplanbegins to pay. If you have other family members on theplan, each<br>family member must meet their own individualdeductibleuntil the total amount of<br>deductible expenses paid by all family members meets the overall family deductible.|
|||Thisplancovers some items and services even if you haven’t yet met thedeductible|
|**Are there services covered**<br>**before you meet your**<br>**deductible?**|Yes. Does not apply tocopayments,<br>certainprescription drugsand services<br>listed below as "No charge."|amount. But acopaymentorcoinsurancemay apply. For example, thisplancovers<br>certain preventive services withoutcost-sharingand before you meet your<br>deductible. See a list of covered preventive services at<br>https://www.healthcare.gov/coverage/ preventive-care-benefits/.|
|**Are there otherdeductiblesfor**<br>**specific services?**|No.|You don’t have to meetdeductiblesfor specific services.|
|**What is theout-of-pocket limit**<br>**for thisplan?**|In-network: $6,300 Individual / $12,600<br>Family<br>Out-of-network: Not Applicable|Theout-of-pocket limit is the most you could pay in a year for covered services. If<br>you have other family members in thisplan, they have to meet their own out-of-<br>pocket limits until the overall family out-of-pocket limithas been met.|
|**What is not included in the**<br>**out-of-pocket limit?**|Premium, balance-billedcharges,<br>penalties for failure to obtainprior<br>authorizationfor services, and health care<br>thisplan doesn't cover.|Even though you pay these expenses, they don’t count toward theout-of-pocket<br>limit.|
|**Will you pay less if you use a**<br>**network provider?**|Yes. See Legacy and Dental Select<br>medical network. For a list ofin-network<br>providers,seehttps://www.premera.com<br>or call 1-800-809-9361.|You pay the least if you use aproviderin our preferred network. You pay more if<br>you use aproviderin our non-preferred network. You will pay the most if you use an<br>out-of-network provider, and you might receive a bill from aproviderfor the<br>difference between theprovider’scharge and what yourplanpays (balance<br>billing).Be aware yournetwork providermight use anout-of-network providerfor<br>some services (such as lab work). Check with your provider before you get services.|
|**Do you need a referral to see a**<br>**specialist?**|No.|You can see thespecialistyou choose without areferral.|



**1 of 7**

All copayment and coinsurance costs shown in this chart are after your overall deductible has been met, if a deductible applies. 



|**Common**|**Si Y M Nd**|**What**<br>|**You Will Pay**<br>|**Limitations, Exceptions, & Other**|
|---|---|---|---|---|
|**Medical Event**|**ervces ou ay ee**|**Network Provider**<br>**(You will pay the least)**|**Out-Of-Network Provider**<br>**(You will pay the most)**|**Important Information**|
|**If you visit a health**|Primary care visit to treat<br>an injury or illness|First two visits: $1copay/<br>visit,deductibledoes not<br>apply. Additional visits: $30<br>copay/ visit,deductible<br>does not apply.|Non-Participating: 60%coinsurance|–––––––––––none–––––––––––|
|**careprovider’s office**<br>**or clinic**|Specialistvisit|$60copay/ visit,<br>deductible does not apply.|Non-Participating: 60%coinsurance|–––––––––––none–––––––––––|
||Preventive care/screening<br>/ immunization|No charge|Non-Participating: 60%coinsurance|You may have to pay for services that<br>aren’tpreventive. Ask yourproviderif<br>the services needed arepreventive.<br>Then check whatyourplanwillpayfor.|
||Diagnostic test(x-ray,<br>blood work)|Preferred: 30%<br>coinsurance.Participating:<br>40% coinsurance|Non-Participating: 60%coinsurance|–––––––––––none–––––––––––|
|**If you have a test**|Imaging (CT/PET scans,<br>MRIs)|Preferred: 30%<br>coinsurance.Participating:<br>40%coinsurance|Non-Participating: 60%coinsurance|Prior authorizationrequired for some<br>outpatient imaging tests. The penalty<br>is: 50% of the allowable charge up to a<br>maximum of$1,500per occurrence.|
|**If you need drugs to**<br>**treat your illness or**<br>**condition**<br>|Preferred generic drugs|$15copay/ prescription<br>(retail)<br>$45copay/ prescription<br>(mail)<br>Deductible does not apply.|$15copay/ prescription (retail)<br>Not covered (mail)<br>Deductibledoes not apply.|Covers up to a 30 day supply (retail),<br>covers up to a 90 day supply (mail). No<br>charge for specific preventive drugs.<br>Prior authorization required for some<br>drugs.|
|More information about<br>**prescription drug**<br>**coverage**is available at<br>https://www.premera.co<br>m/documents/062279_2|Preferred brand drugs|<br>$45copay/ prescription<br>(retail)<br>$135copay/ prescription<br>(mail)<br>Deductible does not apply.|$45copay/ prescription (retail)<br>Not covered (mail)<br>Deductibledoes not apply.|<br>Covers up to a 30 day supply (retail),<br>covers up to a 90 day supply (mail). No<br>charge for specific preventive drugs.<br>Prior authorization required for some<br>drugs.|



**2 of 7**

|**Common**||**What**<br>|**You Will Pay**<br>|**Limitations, Exceptions, & Other**|
|---|---|---|---|---|
|**Medical Event**|**Services You May Need**|**Network Provider**<br>**(You will pay the least)**|**Out-Of-Network Provider**<br>**(You will pay the most)**|<br>**Important Information**|
|025.pdf.|Non-preferred brand drugs|50%coinsurance|50%coinsurance(retail)<br>Not covered (mail)|Covers up to a 30 day supply (retail),<br>covers up to a 90 day supply (mail). No<br>charge for specific preventive drugs.<br>Prior authorization required for some<br>drugs.|
||Specialty drugs|40%coinsurance|40%coinsurance|Covers up to a 30 day supply. Only<br>covered at specific contracted specialty<br>pharmacies. Prior authorization<br>required for some drugs.|
|**If you have outpatient**<br>|Facility fee (e.g.,<br>ambulatory surgery center)|Preferred: 30%<br>coinsurance.Participating:<br>40%coinsurance|Non-Participating: 60%coinsurance|Prior authorizationrequired for some<br>services. The penalty is: 50% of the<br>allowable charge up to a maximum of<br>$1,500 per occurrence.|
|**surgery**|Physician/surgeon fees|Preferred: 30%<br>coinsurance.Participating:<br>40%coinsurance|Non-Participating: 60%coinsurance|–––––––––––none–––––––––––|
||Emergency room care|30%coinsurance|30%coinsurance|–––––––––––none–––––––––––|
||Emergency medical<br>transportation|30%coinsurance|30%coinsurance|–––––––––––none–––––––––––|
|**If you need immediate**<br>**medical attention**|Urgent care|Hospital-based: 30%<br>coinsurance<br>Freestanding center: $60<br>copay/ visit,deductible<br>does not apply.|Hospital-based: 30%coinsurance<br>Freestanding center: Non-<br>Participating: 60%coinsurance|–––––––––––none–––––––––––|
|**If you have a hospital**<br>|Facility fee (e.g., hospital<br>room)|Preferred: 30%<br>coinsurance.Participating:<br>40%coinsurance|Non-Participating: 60%coinsurance|Prior authorizationrequired for all<br>planned inpatient stays. The penalty is:<br>50% of the allowable charge up to a<br>maximum of $1,500 per occurrence.|
|**stay**|Physician/surgeon fees|Preferred: 30%<br>coinsurance.Participating:<br>40%coinsurance|Non-Participating: 60%coinsurance|<br>–––––––––––none–––––––––––|



**3 of 7**

|**Common**||**What**<br>|**You Will Pay**<br>|**Limitations, Exceptions, & Other**|
|---|---|---|---|---|
|**Medical Event**|**Services You May Need**|**Network Provider**<br>**(You will pay the least)**|**Out-Of-Network Provider**<br>**(You will pay the most)**|<br>**Important Information**|
|||Office Visit: $60copay/<br>visit,deductibledoes not<br>|||
|**If you need mental**<br>**health, behavioral**<br>**health, or substance**|Outpatient services|apply.<br>Facility: Preferred: 30%<br>coinsurance.Participating:<br>40% coinsurance|Non-Participating: 60%coinsurance|–––––––––––none–––––––––––|
|**abuse services**|Inpatient services|Preferred: 30%<br>coinsurance.Participating:<br>40%coinsurance|Non-Participating: 60%coinsurance|Prior authorizationrequired for all<br>planned inpatient stays. The penalty is:<br>50% of the allowable charge up to a<br>maximum of$1,500per occurrence.|
||Office visits|30%coinsurance|Non-Participating: 60%coinsurance|Cost-sharingdoes not apply for<br>preventive services. Depending on the<br>type of services, acoinsurancemay<br>apply. Maternity care may include tests<br>and services described elsewhere in<br>the SBC (such as, ultrasound).|
|**If you are pregnant**|Childbirth/delivery<br>professional services|Preferred: 30%<br>coinsurance.<br>Participating: 40%<br>coinsurance|Non-Participating: 60%coinsurance|Cost-sharingdoes not apply for<br>preventive services. Depending on the<br>type of services, acoinsurancemay<br>apply. Maternity care may include tests<br>and services described elsewhere in<br>the SBC (such as, ultrasound).|
||Childbirth/delivery facility<br>services|Preferred: 30%<br>coinsurance.<br>Participating: 40%<br>coinsurance|Non-Participating: 60%coinsurance|Cost-sharingdoes not apply for<br>preventive services. Depending on the<br>type of services, acoinsurancemay<br>apply. Maternity care may include tests<br>and services described elsewhere in<br>the SBC (such as, ultrasound).<br>Prior authorizationis not required.<br>However, you should notify the carrier<br>of your admission for delivery as soon<br>as reasonably possible.|
|**If you need help**<br>**recovering or have**|Home health care|Preferred: 30%<br>coinsurance.Participating:<br>40% coinsurance|Non-Participating: 60%coinsurance|Limited to 130 visits per calendar year|



**4 of 7**

|**Common**||**What**|**You Will Pay**|**Limitations Excetions & Other**|
|---|---|---|---|---|
|<br>**Medical Event**|**Services You May Need**|**Network Provider**<br>**(You will pay the least)**|**Out-Of-Network Provider**<br>**(You will pay the most)**|**, p,**<br>**Important Information**|
|**other special health**<br>**needs**|Rehabilitation services|Outpatient: $60copay/<br>visit<br>Inpatient: Preferred: 30%<br>coinsurance.Participating:<br>40%coinsurance|Non-Participating: 60%coinsurance|Limited to 45 outpatient visits per<br>calendar year, limited to 30 inpatient<br>days per calendar year.Prior<br>authorizationrequired for all planned<br>inpatient stays. The penalty is: 50% of<br>the allowable charge up to a maximum<br>of $1,500 per occurrence.|
||Habilitation services|Outpatient: $60copay/<br>visit<br>Inpatient: Preferred: 30%<br>coinsurance.Participating:<br>40%coinsurance|Non-Participating: 60%coinsurance|Limited to 45 outpatient visits per<br>calendar year, limited to 30 inpatient<br>days per calendar year.Prior<br>authorizationrequired for all planned<br>inpatient stays. The penalty is: 50% of<br>the allowable charge up to a maximum<br>of $1,500 per occurrence.|
||Skilled nursing care|Preferred: 30%<br>coinsurance.Participating:<br>40%coinsurance|Non-Participating: 60%coinsurance|Limited to 60 days per calendar year.<br>Prior authorizationrequired for all<br>planned inpatient stays. The penalty is:<br>50% of the allowable charge up to a<br>maximum of $1,500 per occurrence.|
||Durable medical equipment|Preferred: 30%<br>coinsurance.Participating:<br>40%coinsurance|Non-Participating: 60%coinsurance|Prior authorizationrequired to buy<br>some medical equipment over $750.<br>The penalty is: 50% of the allowable<br>charge up to a maximum of $1,500 per<br>occurrence.|
||Hospice service|Preferred: 30%<br>coinsurance.Participating:<br>40%coinsurance|Non-Participating: 60%coinsurance|Limited to 240 respite hours, limited to<br>10 inpatient days – 6 months overall<br>lifetime benefit limit.|
||Children's eye exam|$30copay/ visit<br>Deductibledoes not apply.|$30copay/ visit<br>Deductibledoes not apply.|Limited to one exam per calendar year<br>(under age 19).|
|**If your child needs**<br>**dental or eye care**|Children's glasses|No charge|No charge|Frames and lenses limited to 1 pair per<br>calendar year.|
||Children's dental check-up|No charge|30%coinsurance|–––––––––––none–––––––––––|



**5 of 7**

# **<u>Excluded Services & Other Covered Services:</u>** 

## **<mark>Services Your Plan Generally Does NOT Cover (Check your policy or plan document for more information and a list of any other excluded services.)</mark>** 

- Assisted fertility treatment • Dental care (Adult) • Private-duty nursing 

- • Bariatric surgery • Hearing aids • Routine eye care (Adult) • <u>Cosmetic surgery</u> • <u>Long-term care</u> • <u>Weight loss programs</u> 

## **<mark>Other Covered Services (Limitations may apply to these services. This isn’t a complete list. Please see your plan document.)</mark>** 

- Abortion • Chiropractic care or other spinal • Foot care 

- • <u>Acupuncture</u> manipulations • <u>Non-emergency care when traveling outside the U.S.</u> 

**Your Rights to Continue Coverage:** There are agencies that can help if you want to continue your coverage after it ends. The contact information for those agencies is: 1-907-269-7900 or 1-800-467-8725 for the state insurance department, or the insurer at 1-800-809-9361 or TTY 711. Other coverage options may be available to you too, including buying individual insurance coverage through the Health Insurance Marketplace. For more information about the Marketplace, visit <u>www.HealthCare.gov</u> or call 1-800-318-2596. 

**Your Grievance and Appeals Rights:** There are agencies that can help if you have a complaint against your plan for a denial of a claim. This complaint is called a <u>grievance or appeal. For more information about your rights, look at the explanation of benefits you will receive for that medical claim. Your plan documents also</u> provide complete information to submit a claim, <u>appeal, or grievance for any reason to your plan. For more information about your rights, this notice, or assistance,</u> contact: your plan at 1-800-809-9361, or the state insurance department at 1-907-269-7900 or 1-800-467-8725. 

**Does this plan provide Minimum Essential Coverage? Yes.** 

<u>Minimum Essential Coverage generally includes plans, health insurance available through the Marketplace or other individual market policies, Medicare, Medicaid,</u> CHIP, TRICARE, and certain other coverage. If you are eligible for certain types of Minimum Essential Coverage, you may not be eligible for the premium tax credit. **Does this plan meet Minimum Value Standards? Not Applicable.** 

If your plan doesn’t meet the Minimum Value Standards, you may be eligible for a premium tax credit to help you pay for a plan through the Marketplace. **Language Access Services:** 

Spanish (Español): Para obtener asistencia en Español, llame al 1-800-809-9361 or TTY 711. Tagalog (Tagalog): Kung kailangan ninyo ang tulong sa Tagalog tumawag sa 1-800-809-9361 or TTY 711. Chinese (中文): 如果需要中文的帮助， 请拨打这个号码 1-800-809-9361 or TTY 711. 

Navajo (Dine): Dinek'ehgo shika at'ohwol ninisingo, kwiijigo holne' 1-800-809-9361 or TTY 711. 

––––––––––––––––––– _To see examples of how this plan might cover costs for a sample medical situation, see the next section.–––––––––––_ ––––––– 

**6 of 7**

# **<u>About these Coverage Examples:</u>** 



**This is not a cost estimator.** Treatments shown are just examples of how this plan might cover medical care. Your actual costs will be different depending on the actual care you receive, the prices your providers charge, and many other factors. Focus on the cost sharing amounts (deductibles, <u>copayments and coinsurance) and excluded services under the plan. Use this information to compare the portion of costs you might pay under different health plans. Please note these coverage examples are based on self-only coverage.</u> 

|**Peg is Having a baby**||**Managing Joe's type 2 diab**|**etes**|**Mia's Simple Fracture**||
|---|---|---|---|---|---|
|(9 months of in-network pre-natal care<br>hospital delivery)|and a|(a year of routine in-network care of<br>controlled condition)|a well-|(in-network emergency room visit and<br>care)|follow up|
| **Theplan's overalldeductible**|$1,500<br>| **Theplan's overalldeductible**|$1,500| **Theplan's overalldeductible**|$1,500<br>|
| **Specialist copay**|$60| **Specialist copay**|$60| **Specialist copay**|$60|
| **Hospital (facility)coinsurance**|30%| **Hospital (facility)coinsurance**|30%| **Hospital (facility)coinsurance**|30%|
| **Othercoinsurance**|30%| **Othercoinsurance**|30%| **Othercoinsurance**|30%|
|**This EXAMPLE event includes services**<br>Specialistoffice visits (_prenatal care_)<br>Childbirth/Delivery Professional Services|**like:**|**This EXAMPLE event includes service**<br>Primary care physician office visits (_includ_<br>_education_)|**s like:**<br>_ing disease_|**This EXAMPLE event includes service**<br>Emergency room care (_including medica_<br>_supplies_)|**s like:**<br>_l_|
|Childbirth/Delivery Facility Services<br>Diagnostic tests (_ultrasounds and blood w_<br>Specialistvisit (_anesthesia_)|_ork_)|Diagnostic tests (_blood work_)<br>Prescription drugs<br>Durable medical equipment (_glucose met_|_er_)|Diagnostic test (_x-ray_)<br>Durable medical equipment (_crutches_)<br>Rehabilitation services (_physical therapy_|)|
|**Total Example Cost**|$12,700|**Total Example Cost**|$5,600|**Total Example Cost**|$2,800|
|**In this example, Peg would pay:**||**In this example, Joe would pay:**||**In this example, Mia would pay:**||
|_Cost Sharing_||_Cost Sharing_||_Cost Sharing_||
|Deductibles|$1,500|Deductibles|$200|Deductibles|$1,500|
|Copayments|$10|Copayments|$1,600|Copayments|$300|
|Coinsurance|$3,300|Coinsurance|$0|Coinsurance|$300|
|_What isn't covered_||_What isn't covered_||_What isn't covered_||
|Limits or exclusions|$60|Limits or exclusions|$20|Limits or exclusions|$0|
|**The Total Peg wouldpay is**|**$4,870**|**The Total Joe wouldpay is**|**$1,820**|**The Total Mia wouldpay is**|**$2,100**|



The **<u>plan</u>** would be responsible for the other costs of these EXAMPLE covered services. 

045632 (08-01-2024) 

Premera Blue Cross is an Independent Licensee of the Blue Cross Blue Shield Association 

MET-INDIV-WA 38344AK1060001-01 

**7 of 7**

**Notice of availability and nondiscrimination 800-809-9361 | TTY: 711** 

Call for free language assistance services and appropriate auxiliary aids and services. Tumawag para sa mga libreng serbisyo ng tulong sa wika at angkop na mga karagdagang tulong at serbisyo. Llame para obtener servicios gratuitos de asistencia lingüística, y ayudas y servicios auxiliares apropiados. 무료 언어 지원 서비스와 적절한 보조 도구 및 서비스를 신청하십시오. 

Hu thov kev pab txhais lus pub dawb thiab lwm yam khoom pab dawb thiab kev pab cuam ua tsim nyog. Звоните для получения бесплатных услуг по переводу и других вспомогательных средств и услуг. 呼吁提供免费的语言援助服务和适当的辅助设备及服务。 呼籲提供免費的語言援助服務和適當的輔助設備及服務。 

Valaʻau mo auaunaga tau fesoasoani mo gagana e leai ni totogi ma fesoasoani faʻaopoʻopo talafeagai ma auaunaga. ໂທເພຼືື່ອຮັບການບໍລິການຊື່ວຍເຫ ຼືອດ້ານພາສາ ແລະ ການບໍລິການ ແລະ ການຊື່ວຍເຫ ຼືອພິເສດທ ື່ເໝາະສົມແບບບໍື່ເສຍຄື່າ. `無料言語支援サービスと適切な補助器具及びサービスをお求めください。` 

Tumawag para kadagiti libre a serbisio iti tulong iti pagsasao ken dagiti nakanada nga aid ken serbisio iti komunikasion. Gọi cho các dịch vụ hỗ trợ ngôn ngữ miễn phí và các hỗ trợ và dịch vụ phụ trợ thích hợp. 

Звертайтесь за безкоштовною мовною підтримкою та відповідними додатковими послугами. ติดต่อขอบริการช่วยเหลือด้านภาษาฟรีพร้อมความช่วยเหลือและบริการอื่น ๆ เพิ่มเติม Fordern Sie kostenlose Sprachunterstützungsdienste und geeignete Hilfsmittel und Dienstleistungen an. Zadzwoń, aby uzyskać bezpłatną pomoc językową oraz odpowiednie wsparcie i usługi pomocnicze. Rele pou w jwenn sèvis asistans lengwistik gratis ak èd epi sèvis oksilyè ki apwopriye. 

Appelez pour obtenir des services gratuits d’assistance linguistique et des aides et services auxiliaires appropriés. Ligue para serviços gratuitos de assistência linguística e auxiliares e serviços auxiliares adequados. Chiama per i servizi di assistenza linguistica gratuiti e per gli ausili e i servizi ausiliari appropriati. 

.اتصل للحصول على خدمات المساعدة اللغوية المجانية والمساعدات والخدمات المناسبة بگيريد.،مقتضی تماس ها و خدمات امدادی برای خدمات کمک زبانی رايگان و کمک 

**Discrimination is against the law.** Premera Blue Cross Blue Shield of Alaska (Premera) complies with applicable Federal civil rights laws and does not discriminate on the basis of race, color, national origin, age, disability, or sex, including sex characteristics, intersex traits, pregnancy or related conditions, sexual orientation, gender identity, and sex stereotypes. Premera does not exclude people or treat them less favorably because of race, color, national origin, age, disability, or sex. Premera provides people with disabilities reasonable modifications and free appropriate auxiliary aids and services to communicate effectively with us, such as qualified sign language interpreters and written information in other formats (large print, audio, accessible electronic formats, other formats). Premera provides free language assistance services to people whose primary language is not English, which may include qualified interpreters and information written in other languages. If you need reasonable modifications, appropriate auxiliary aids and services, or language assistance services, contact our Civil Rights Coordinator. If you believe that Premera has failed to provide these services or discriminated in another way on the basis of race, color, national origin, age, disability, or sex, you can file a grievance with: Civil Rights Coordinator ─ Complaints and Appeals, PO Box 91102, Seattle, WA 98111, Toll free: 855-332-4535, TTY: 711, Fax: 425-918-5592, Email AppealsDepartmentInquiries@Premera.com. You can file a grievance in person or by mail, fax, or email. If you need help filing a grievance, our Civil Rights Coordinator is available to help you. You can also file a civil rights complaint with the U.S. Department of Health and Human Services, Office for Civil Rights, electronically through the Office for Civil Rights Complaint Portal, available at https://ocrportal.hhs.gov/ocr/portal/lobby.jsf, or by mail or phone at: U.S. Department of Health and Human Services, 200 Independence Ave SW, Room 509F, HHH Building, Washington, D.C. 20201, 1-800-368-1019, 800-537-7697 (TDD). Complaint forms are available at http://www.hhs.gov/ocr/office/file/index.html. 



An Independent Licensee of the Blue Cross Blue Shield Association 051269 (07-05-2024)