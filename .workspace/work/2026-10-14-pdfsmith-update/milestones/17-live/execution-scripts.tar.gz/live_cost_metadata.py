from pathlib import Path
import os,sys,json
r=Path(__file__).parent;sys.path.insert(0,str(r));from live_credentials import environment
env=environment();os.environ.clear();os.environ.update(env)
from google.auth import load_credentials_from_file
from google.cloud import documentai_v1 as documentai
from google.api_core.client_options import ClientOptions
out=r/'live-results';result={}
try:
 credentials,_=load_credentials_from_file(str(Path.home()/'.config/gcloud/application_default_credentials.json'),scopes=['https://www.googleapis.com/auth/cloud-platform'])
 c=documentai.DocumentProcessorServiceClient(credentials=credentials,client_options=ClientOptions(api_endpoint=env.get('GOOGLE_CLOUD_LOCATION','us')+'-documentai.googleapis.com'),transport='rest')
 try:
  name=f"projects/{env['GOOGLE_CLOUD_PROJECT']}/locations/{env.get('GOOGLE_CLOUD_LOCATION','us')}/processors/{env['GOOGLE_DOCUMENT_AI_PROCESSOR_ID']}"
  p=c.get_processor(name=name,retry=None,timeout=20);result={'alternate_existing_adc_metadata_read':'passed','processor_type':p.type_,'processor_state':p.state.name}
 finally:c.transport.close()
except Exception as e:result={'alternate_existing_adc_metadata_read':'failed','error_class':type(e).__name__}
(out/'cost-metadata.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
