import argparse,json,sys,os,hashlib,datetime,re
from pathlib import Path
import pdfsmith
p=argparse.ArgumentParser();p.add_argument('--provider',required=True);p.add_argument('--input',type=Path,required=True);p.add_argument('--options',type=Path,required=True);p.add_argument('--result',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
assert not any(k.startswith('DATABRICKS') for k in os.environ)
assert args.provider!='databricks' and not os.getenv('_PDFSMITH_TEST_OFFLINE')
record={'provider':args.provider,'route':'public parse API','start':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_sha256':hashlib.sha256(args.input.read_bytes()).hexdigest(),'version':pdfsmith.__version__}
try:
 text=pdfsmith.parse(args.input,backend=args.provider,backend_options=json.loads(args.options.read_text()))
 args.output.write_bytes(text.encode('utf-8'));record.update(success=True,output_sha256=hashlib.sha256(args.output.read_bytes()).hexdigest(),output_bytes=args.output.stat().st_size)
except Exception as e:
 message=str(e)
 for key,value in os.environ.items():
  if any(part in key for part in ('API_KEY','SECRET','SESSION_TOKEN')) and len(value)>5:message=message.replace(value,'[REDACTED]')
 message=re.sub(r'sk-[A-Za-z0-9_.*-]+','[REDACTED_KEY]',message)
 record.update(success=False,error_class=type(e).__name__,error=message,completion_unknown=bool(getattr(e,'completion_unknown',False)),resource_ids=getattr(e,'resource_ids',{}),cleanup_errors=getattr(e,'cleanup_errors',()))
 if getattr(e,'recovered_content',None) is not None:
  args.output.write_bytes(e.recovered_content.encode('utf-8'));record['recovered_content_saved']=True
finally:
 record['end']=datetime.datetime.now(datetime.timezone.utc).isoformat();args.result.write_text(json.dumps(record,indent=2)+'\n');args.result.chmod(0o600)
print(json.dumps({k:v for k,v in record.items() if k in {'provider','success','error_class','output_bytes','completion_unknown'}}),flush=True)
sys.exit(0 if record['success'] else 1)
