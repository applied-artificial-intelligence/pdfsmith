from pathlib import Path
from decimal import Decimal
import json,hashlib,datetime,subprocess,tarfile,os,sys,importlib.metadata,re
r=Path(__file__).parent.resolve();w=r.parent;m=w/'milestones/17-live';out=r/'live-results'
ledger=json.loads((out/'ledger.json').read_text())
# Processor metadata is inaccessible. Include the published document-based tariffs,
# rather than assume the lower OCR rate for its ten successfully processed pages.
ledger['budget_adjustments']=[{'provider':'google_document_ai','reserved_usd':'1.00','reason':'Retain USD 1.50 total for two documents because processor type/tariff metadata could not be read. This adds no processing requests.'}]
ledger['retained_reservations_usd']=str(sum((Decimal(x['reserved_usd']) for x in ledger['attempts']),Decimal(0))+Decimal('1.00'))
assert Decimal(ledger['retained_reservations_usd'])<=Decimal('5.00')
(out/'ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
checks=json.loads((out/'file-cleanup-confirmation.json').read_text())
providers=['aws_textract','azure_document_intelligence','google_document_ai','llamaparse','anthropic','openai','gemini'];rows=[];measurements=[]
for provider in providers:
 keys=[x['key'] for x in ledger['attempts'] if x['key'].startswith(provider+'-')];attempts=[]
 for key in keys:
  directory=out/key;record=json.loads((directory/'result.json').read_text());entry=next(x for x in ledger['attempts'] if x['key']==key)
  events=[json.loads(x) for x in (directory/'receipts.jsonl').read_text().splitlines()] if (directory/'receipts.jsonl').exists() else []
  attempt={k:record[k] for k in ('success','route','output_bytes','output_sha256','input_sha256','error_class','completion_unknown') if k in record}
  attempt.update(key=key,source_commit=entry['source_commit'],wheel_sha256=entry['wheel_sha256'],input_sha256=entry['input_sha256'],options={k:v for k,v in entry['options'].items() if k not in {'profile','project_id','processor_id','endpoint','gcs_bucket'}},command_sha256=hashlib.sha256((directory/'command.json').read_bytes()).hexdigest())
  if record.get('success'):
   text=(directory/'output.txt').read_text()
   if '-cli' in key:attempt['content_checks']={'first_page_sentinel':'FIRST PAGE SENTINEL' in text,'final_page_sentinel':'FINAL PAGE SENTINEL' in text}
   else:attempt['content_checks']={'premera_identity':'premera' in text.lower(),'last_page_hhs_phone':bool(re.search(r'800[\s-]*368[\s-]*1019',text))}
   assert all(attempt['content_checks'].values()),key
  usage=[x['usage'] for x in events if x.get('usage') is not None]
  if usage:attempt['reported_usage']=usage[-1]
  attempts.append(attempt)
 status='live-e2e' if sum(x['success'] for x in attempts)==2 else 'live-blocked'
 row={'provider':provider,'status':status,'live_python':'3.12','attempts':attempts,'settled_bill_usd':None}
 if provider in {'aws_textract','azure_document_intelligence'}:
  row.update(actual_pages_processed=10,standard_rate_equivalent_usd='0.015',cost_basis='10 successfully validated pages at USD 1.50/1000. Azure uses the checked East US Read reference rate; invoice/resource-region discount not confirmed.')
 elif provider=='google_document_ai':
  row.update(actual_pages_processed=10,rate_calculated_cost_usd=None,cost_basis='Processing passed; processors.get denied and alternate existing ADC/CLI credentials could not refresh. The processor-specific tariff is unconfirmed.',ocr_rate_scenario_usd='0.015',retained_tariff_allowance_usd='1.50')
 elif provider=='llamaparse':
  row.update(actual_pages_processed=10,requested_tier='fast',requested_version='2026-06-15',expected_credits_at_published_rate=10,standard_rate_equivalent_usd='0.0125',cost_basis='Ten successfully processed pages at one Fast credit/page and USD 1.25/1000 credits. Job responses did not report a credit debit; settled bill unknown.',rejected_submission='Original HTTP 422 before job creation; rejected upload deleted.')
 elif provider=='anthropic':
  total=Decimal(0);input_tokens=0;output_tokens=0
  for attempt in attempts:
   u=attempt['reported_usage'];input_tokens+=u['input_tokens'];output_tokens+=u['output_tokens']
   assert u.get('cache_creation_input_tokens',0)==0 and u.get('cache_read_input_tokens',0)==0
   total+=(Decimal(u['input_tokens'])+Decimal(u['output_tokens'])*Decimal(5))/Decimal(1000000)
  row.update(actual_input_tokens=input_tokens,actual_output_tokens=output_tokens,rate_calculated_cost_usd=str(total),cost_basis='Actual SDK response token usage at Haiku 4.5 USD 1/M input and USD 5/M output; not a settled billing receipt.')
 else:
  row.update(actual_successful_generations=0,returned_token_usage=None,rate_calculated_cost_usd=None,billing_block='credit_balance_exhausted' if provider=='openai' else 'prepayment_credits_depleted',cost_basis='Generation rejected for depleted credits; no generated text or token usage returned. No top-up or retry. Settled debit not independently accessible.')
 rows.append(row)
summary={'date':'2026-10-15','authorization':'Seven APIs, aggregate USD 5, Databricks excluded','document_processing_finished':True,'successful_providers':sum(x['status']=='live-e2e' for x in rows),'blocked_providers':['openai','gemini'],'databricks':{'attempted':False,'credentials_passed_to_workers':False},'budget':{'ceiling_usd':'5.00','initial_attempt_reservations_usd':str(sum((Decimal(x['reserved_usd']) for x in ledger['attempts']),Decimal(0))),'additional_google_unknown_tariff_allowance_usd':'1.00','retained_reservations_usd':ledger['retained_reservations_usd'],'actual_settled_total_usd':None,'known_standard_rate_equivalent_excluding_google_usd':'0.101445','total_if_google_ocr_standard_rate_usd':'0.116445','reason_not_an_invoice':'Provider billing/free allowances/regional rates are not confirmed. Google processor tariff is unknown. Reservations include rejected and uncertain charges and are not spending.'},'providers':rows,'cleanup':[{k:v for k,v in x.items() if k!='file_id'} for x in checks],'receipt_limitations':'Original Azure/Google calls did not have raw HTTP response telemetry captured. Their actual public API and console returned only after wrapper completion/page/cleanup checks; their operation IDs are unavailable in this audit. Initial Llama API job usage was not captured; the later CLI audit captured job state but no usage debit was returned.'}
(m/'results.json').write_text(json.dumps(summary,indent=2)+'\n')
# Safe audit metadata omits resource/operation identifiers, headers, credentials and raw errors.
receipts=[]
for row in rows:
 for attempt in row['attempts']:
  path=out/attempt['key']/'receipts.jsonl'
  for line in path.read_text().splitlines() if path.exists() else []:
   event=json.loads(line);public={k:v for k,v in event.items() if k in {'time','kind','method','http_status','operation','pages','status','stop_reason','usage','usageMetadata','finish_reasons'}}
   if isinstance(event.get('job'),dict):public['job']={k:v for k,v in event['job'].items() if k in {'status','tier','version','usage'}}
   public['attempt']=attempt['key'];receipts.append(public)
(m/'receipts-sanitized.json').write_text(json.dumps(receipts,indent=2)+'\n')
(m/'dependencies.json').write_text(json.dumps({d.metadata['Name']:d.version for d in importlib.metadata.distributions()},indent=2,sort_keys=True)+'\n')
paths=['src/pdfsmith/backends/openai_backend.py','src/pdfsmith/backends/llamaparse_backend.py','tests/test_openai_contracts.py','tests/test_llamaparse_contracts.py','tests/verify_distribution.py','README.md']
(m/'source-identity.json').write_text(json.dumps({p:hashlib.sha256((r.parents[3]/p).read_bytes()).hexdigest() for p in paths},indent=2)+'\n')
with tarfile.open(m/'public-document-outputs.tar.gz','w:gz') as archive:
 for row in rows:
  for attempt in row['attempts']:
   if attempt['success']:archive.add(out/attempt['key']/'output.txt',arcname=attempt['key']+'/output.txt')
# Raw execution scripts contain configuration names, never credential values.
with tarfile.open(m/'execution-scripts.tar.gz','w:gz') as archive:
 for name in ['live_credentials.py','live_preflight.py','live_audit.py','live_worker.py','live_submit.py','live_continue.py','live_reconcile_cleanup.py','live_cost_metadata.py','live_gcloud_metadata.py','live_report.py']:archive.add(r/name,arcname=name)
versions=json.loads((out/'llama-service-versions.json').read_text());(m/'llama-service-versions.json').write_text(json.dumps(versions,indent=2)+'\n')
print('Report written: 5 passed, 2 billing-blocked; reservations',ledger['retained_reservations_usd'],'USD; no settled invoice total claimed')
