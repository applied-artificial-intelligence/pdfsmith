import sys,os,json,datetime,asyncio,re
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from live_credentials import environment
selected=environment();os.environ.clear();os.environ.update(selected)
assert not any(k.startswith('DATABRICKS') for k in os.environ)
root=Path(__file__).parent;out=root/'live-results';out.mkdir(exist_ok=True);out.chmod(0o700)
secrets=[v for k,v in selected.items() if ('KEY' in k or 'SECRET' in k or 'TOKEN' in k) and len(v)>5]
def safe(value):
 text=str(value)
 for secret in secrets:text=text.replace(secret,'[REDACTED]')
 text=re.sub(r'sk-[A-Za-z0-9_.*-]+','[REDACTED_KEY]',text)
 text=re.sub(r'AIza[A-Za-z0-9_-]+','[REDACTED_KEY]',text)
 return text
results={}
def run(name,operation):
 try:result=operation();results[name]={'credential_check':'passed',**result}
 except Exception as e:results[name]={'credential_check':'failed','error_class':type(e).__name__,'error':safe(e)}
 (out/'preflight.json').write_text(json.dumps(results,indent=2)+'\n');(out/'preflight.json').chmod(0o600)
 print(name,results[name]['credential_check'],results[name].get('error_class',''),flush=True)

def aws():
 import boto3
 from botocore.config import Config
 c=boto3.Session(profile_name=selected.get('AWS_PROFILE'),region_name=selected.get('AWS_REGION','us-east-1')).client('sts',config=Config(connect_timeout=10,read_timeout=20,retries={'max_attempts':0}))
 try:c.get_caller_identity();return {'selected_profile_valid':True,'region':selected.get('AWS_REGION','us-east-1')}
 finally:c.close()
def azure():
 from azure.ai.documentintelligence import DocumentIntelligenceAdministrationClient
 from azure.core.credentials import AzureKeyCredential
 c=DocumentIntelligenceAdministrationClient(selected['AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT'],AzureKeyCredential(selected['AZURE_DOCUMENT_INTELLIGENCE_KEY']),connection_timeout=10,read_timeout=20,retry_total=0)
 try:info=c.get_resource_details();return {'document_models_count':info.custom_document_models.count,'read_endpoint_accessible':True}
 finally:c.close()
def google():
 from google.cloud import documentai_v1 as documentai
 from google.api_core.client_options import ClientOptions
 location=selected.get('GOOGLE_CLOUD_LOCATION','us')
 c=documentai.DocumentProcessorServiceClient(client_options=ClientOptions(api_endpoint=f'{location}-documentai.googleapis.com'),transport='rest')
 try:
  name=f"projects/{selected['GOOGLE_CLOUD_PROJECT']}/locations/{location}/processors/{selected['GOOGLE_DOCUMENT_AI_PROCESSOR_ID']}"
  p=c.get_processor(name=name,retry=None,timeout=20)
  return {'processor_type':p.type_,'processor_state':p.state.name,'location':location,'processor_name':name,'default_processor_version':p.default_processor_version}
 finally:c.transport.close()
def llama():
 from llama_cloud import LlamaCloud
 c=LlamaCloud(api_key=selected['LLAMA_CLOUD_API_KEY'],max_retries=0,timeout=20)
 try:c.files.list(page_size=1);return {'files_listing_accessible':True}
 finally:c.close()
def anthropic():
 from anthropic import Anthropic
 c=Anthropic(api_key=selected['ANTHROPIC_API_KEY'],max_retries=0,timeout=20)
 try:m=c.models.retrieve('claude-haiku-4-5-20251001');return {'model_id':m.id}
 finally:c.close()
def openai():
 from openai import OpenAI
 c=OpenAI(api_key=selected['OPENAI_API_KEY'],max_retries=0,timeout=20)
 try:m=c.models.retrieve('gpt-4o-mini');return {'model_id':m.id}
 finally:c.close()
def gemini():
 from google import genai
 from google.genai import types
 c=genai.Client(api_key=selected.get('GOOGLE_API_KEY') or selected['GEMINI_API_KEY'],enterprise=False,http_options=types.HttpOptions(timeout=20000,retry_options=types.HttpRetryOptions(attempts=1)))
 try:
  m=c.models.get(model='gemini-2.5-flash');return {'model_name':m.name,'input_token_limit':m.input_token_limit,'output_token_limit':m.output_token_limit}
 finally:c.close();asyncio.run(c.aio.aclose())
for name,operation in [('aws_textract',aws),('azure_document_intelligence',azure),('google_document_ai',google),('llamaparse',llama),('anthropic',anthropic),('openai',openai),('gemini',gemini)]:run(name,operation)
print('Read-only credential checks finished; no document processing submitted',flush=True)
