from pathlib import Path
import os,sys,json,subprocess,shutil
r=Path(__file__).parent;sys.path.insert(0,str(r));from live_credentials import environment
selected=environment();result={}
if shutil.which('gcloud'):
 p=subprocess.run(['gcloud','auth','print-access-token','--quiet'],env=selected,capture_output=True,text=True,timeout=40)
 if p.returncode==0 and p.stdout.strip():
  import requests
  location=selected.get('GOOGLE_CLOUD_LOCATION','us');name=f"projects/{selected['GOOGLE_CLOUD_PROJECT']}/locations/{location}/processors/{selected['GOOGLE_DOCUMENT_AI_PROCESSOR_ID']}"
  response=requests.get(f'https://{location}-documentai.googleapis.com/v1/{name}',headers={'Authorization':'Bearer '+p.stdout.strip()},timeout=20)
  result={'existing_active_gcloud_credential':'token available','metadata_http_status':response.status_code}
  if response.ok:
   j=response.json();result.update(processor_type=j.get('type'),processor_state=j.get('state'),default_processor_version=j.get('defaultProcessorVersion'))
 else:result={'existing_active_gcloud_credential':'refresh failed','exit':p.returncode}
else:result={'existing_active_gcloud_credential':'CLI not installed'}
(r/'live-results/gcloud-cost-metadata.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='default_processor_version'}))
