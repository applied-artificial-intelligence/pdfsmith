import datetime,json,os,socket
from pathlib import Path
from urllib.parse import urlsplit

TARGET=os.getenv('PDFSMITH_LIVE_AUDIT_PATH')

def emit(record):
 if TARGET:
  record['time']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with Path(TARGET).open('a',encoding='utf-8') as f:f.write(json.dumps(record,default=str)+'\n')

def install():
 if not TARGET:return
 original_dns=socket.getaddrinfo
 def dns(host,*args,**kwargs):
  if isinstance(host,bytes):host=host.decode()
  if host and 'databricks' in str(host).lower():raise RuntimeError('Databricks is excluded from this run')
  return original_dns(host,*args,**kwargs)
 socket.getaddrinfo=dns
 def observe(response,request):
  url=urlsplit(str(request.url));record={'kind':'http','method':request.method,'host':url.hostname,'path':url.path,'http_status':response.status_code}
  for name in ('request-id','x-request-id','x-ms-request-id','x-ms-region','apim-request-id'):
   if response.headers.get(name):record[name]=response.headers[name]
  try:
   value=response.json()
   if isinstance(value,dict):
    for key in ('id','status','model','modelVersion','responseId','stop_reason','usage','usageMetadata','error'):
     if key in value:record[key]=value[key]
    if isinstance(value.get('job'),dict):record['job']={k:v for k,v in value['job'].items() if k in {'id','status','tier','version','usage'}}
    if isinstance(value.get('analyzeResult'),dict):
     analysis=value['analyzeResult'];record['pages']=len(analysis.get('pages',[]));record['model_id']=analysis.get('modelId')
    if isinstance(value.get('document'),dict):record['pages']=len(value['document'].get('pages',[]))
    if isinstance(value.get('choices'),list):record['finish_reasons']=[c.get('finish_reason') for c in value['choices']]
    if isinstance(value.get('candidates'),list):record['finish_reasons']=[c.get('finishReason') for c in value['candidates']]
  except Exception:pass
  emit(record)
 for package in ('httpx','httpx2'):
  module=__import__(package);original=module.Client.send
  def send(client,request,*args,_original=original,**kwargs):
   response=_original(client,request,*args,**kwargs);observe(response,request);return response
  module.Client.send=send
 import requests
 original_requests=requests.Session.send
 def requests_send(session,request,*args,**kwargs):
  response=original_requests(session,request,*args,**kwargs);observe(response,request);return response
 requests.Session.send=requests_send
 import botocore.client
 original_call=botocore.client.BaseClient._make_api_call
 def aws_call(client,operation,parameters):
  try:
   result=original_call(client,operation,parameters)
   if operation=='DetectDocumentText':emit({'kind':'aws','operation':operation,'http_status':result.get('ResponseMetadata',{}).get('HTTPStatusCode'),'request_id':result.get('ResponseMetadata',{}).get('RequestId'),'pages':result.get('DocumentMetadata',{}).get('Pages')})
   return result
  except Exception as error:
   if operation=='DetectDocumentText':emit({'kind':'aws','operation':operation,'error_class':type(error).__name__})
   raise
 botocore.client.BaseClient._make_api_call=aws_call
