import sys,subprocess,json
from pathlib import Path
r=Path(__file__).parent
providers=['aws_textract','azure_document_intelligence','google_document_ai','llamaparse','anthropic','openai','gemini']
for provider in providers:
 for route in ('api','cli'):
  ledger=json.loads((r/'live-results/ledger.json').read_text())
  existing=next((x for x in ledger['attempts'] if x['key']==f'{provider}-{route}'),None)
  if existing:
   if existing['state']=='success':continue
   if existing['state']=='reserved_before_submission':raise RuntimeError('An attempt is still pending; do not resubmit')
   print(provider,'stopped after existing failed/uncertain attempt',flush=True);break
  p=subprocess.run([sys.executable,str(r/'live_submit.py'),provider,route])
  if p.returncode:
   print(provider,'stopped after failure; continuing the other authorized providers',flush=True);break
print('All approved provider attempts completed or stopped; Databricks excluded',flush=True)
