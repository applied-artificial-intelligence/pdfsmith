from pathlib import Path
import os,sys,json
r=Path(__file__).parent;sys.path.insert(0,str(r));from live_credentials import environment
selected=environment();os.environ.clear();os.environ.update(selected);out=r/'live-results';checks=[]
from llama_cloud import LlamaCloud
from openai import OpenAI
for provider,names,factory in [
 ('llamaparse',['llamaparse-api','llamaparse-api-corrected','llamaparse-cli'],lambda:LlamaCloud(api_key=selected['LLAMA_CLOUD_API_KEY'],max_retries=0,timeout=20)),
 ('openai',['openai-api'],lambda:OpenAI(api_key=selected['OPENAI_API_KEY'],max_retries=0,timeout=20))]:
 c=factory()
 try:
  for name in names:
   events=[json.loads(x) for x in (out/name/'receipts.jsonl').read_text().splitlines()]
   uploads=[x for x in events if x.get('method')=='POST' and x.get('path','').endswith('/files') and x.get('id')]
   for upload in uploads:
    record={'provider':provider,'attempt':name,'file_id':upload['id']}
    try:c.files.retrieve(upload['id']);record['retrieval_http_status']=200
    except Exception as e:record.update(retrieval_http_status=getattr(e,'status_code',None),error_class=type(e).__name__)
    record['confirmed_absent']=record.get('retrieval_http_status')==404;checks.append(record)
 finally:c.close()
(out/'file-cleanup-confirmation.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps([{k:v for k,v in x.items() if k!='file_id'} for x in checks],indent=2))
