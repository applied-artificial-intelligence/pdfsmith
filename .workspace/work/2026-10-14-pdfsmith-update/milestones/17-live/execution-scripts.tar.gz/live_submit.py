import sys,os,json,subprocess,hashlib,datetime,tempfile,fcntl,tarfile
from decimal import Decimal
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from live_credentials import environment
r=Path(__file__).parent.resolve();root=r.parents[3];out=r/'live-results';out.mkdir(exist_ok=True);os.umask(0o077)
provider=sys.argv[1];route=sys.argv[2]
suffix='-corrected' if len(sys.argv)>3 and sys.argv[3]=='corrected' else ''
if suffix:
 assert provider=='llamaparse' and route=='api'
 prior=json.loads((out/'llamaparse-api/result.json').read_text());assert '422' in prior.get('error','')
 cleanup=json.loads((out/'llama-rejected-upload-cleanup.json').read_text());assert cleanup['owned_file_deleted']
reserves={'aws_textract':{'api':'0.08','cli':'0.02'},'azure_document_intelligence':{'api':'0.4','cli':'0.1'},'google_document_ai':{'api':'0.4','cli':'0.1'},'llamaparse':{'api':'0.025','cli':'0.025'},'anthropic':{'api':'0.4','cli':'0.4'},'openai':{'api':'0.04','cli':'0.04'},'gemini':{'api':'0.5','cli':'0.5'}}
assert provider in reserves and route in {'api','cli'},'Provider/route outside approved scope'
env=environment();assert not any(k.startswith('DATABRICKS') for k in env)
options={
 'aws_textract':{'region':env.get('AWS_REGION','us-east-1'),'profile':env.get('AWS_PROFILE'),'request_timeout':60},
 'azure_document_intelligence':{'model_id':'prebuilt-read','output_format':'text','max_wait':180,'poll_interval':1,'request_timeout':60},
 'google_document_ai':{'mode':'sync','max_wait':600,'poll_interval':1,'request_timeout':60},
 'llamaparse':{'tier':'fast','version':'2026-06-15','disable_cache':True,'language':'en','max_wait_seconds':180,'poll_interval_seconds':1,'request_timeout_seconds':60},
 'anthropic':{'model':'claude-haiku-4-5-20251001','max_tokens':32768,'request_timeout':180},
 'openai':{'model':'gpt-4o-mini','max_completion_tokens':16384,'request_timeout':180},
 'gemini':{'model':'gemini-2.5-flash','max_output_tokens':32768,'request_timeout':180},
}[provider]
if route=='api':
 document=Path('/home/stefan/agents/document-evidence/data/raw/AK_38344_38344AK1060001-01.pdf');expected='d93b3432fee068291117ba8d057233c5e1e70a7415be3052f88ccb5204872e80'
else:
 document=r/'ocr-fixtures/two-pages.pdf';expected='257f446840157085e46a4f0832c7a3ed7fcf96727148352879182ddfcc9dbbe5'
assert hashlib.sha256(document.read_bytes()).hexdigest()==expected,'Input differs from authorized bytes'
python=r/'live-env/bin/python';console=r/'live-env/bin/pdfsmith';wheel=r/'live-repair-wheels/pdfsmith-0.3.0.dev0-py3-none-any.whl'
from zipfile import ZipFile
with ZipFile(wheel) as a:
 for name in a.namelist():
  if name.startswith('pdfsmith/') and name.endswith('.py'):
   installed=r/'live-env/lib/python3.12/site-packages'/name
   assert installed.read_bytes()==a.read(name)
key=f'{provider}-{route}{suffix}';job=out/key;job.mkdir();job.chmod(0o700)
options_file=job/'options.json';options_file.write_text(json.dumps(options,indent=2)+'\n')
lock=out/'ledger.lock';ledger=out/'ledger.json'
with lock.open('a') as handle:
 fcntl.flock(handle,fcntl.LOCK_EX)
 data=json.loads(ledger.read_text()) if ledger.exists() else {'currency':'USD','ceiling':'5.00','databricks_excluded':True,'attempts':[]}
 assert not any(item['key']==key for item in data['attempts']),'This processing attempt is already reserved; do not retry automatically'
 total=sum((Decimal(item['reserved_usd']) for item in data['attempts']),Decimal(0));reservation=Decimal(reserves[provider][route]);assert total+reservation<=Decimal('5.00'),'Budget ceiling exceeded'
 if route=='cli':
  prior_file=out/('llamaparse-api-corrected/result.json' if provider=='llamaparse' else f'{provider}-api/result.json');prior=json.loads(prior_file.read_text());assert prior.get('success'),'Provider stopped after API failure'
 data['attempts'].append({'key':key,'reserved_usd':str(reservation),'state':'reserved_before_submission','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'input_sha256':expected,'options':options,'time':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 temporary=out/'ledger.new.json';temporary.write_text(json.dumps(data,indent=2)+'\n');temporary.replace(ledger)
 print(key,'reserved USD',reservation,'aggregate reservations',total+reservation,flush=True)
env['PDFSMITH_LIVE_AUDIT_PATH']=str(job/'receipts.jsonl')
if route=='api':
 command=[str(python),'-I',str(r/'live_worker.py'),'--provider',provider,'--input',str(document),'--options',str(options_file),'--result',str(job/'result.json'),'--output',str(job/'output.txt')]
else:command=[str(console),'parse',str(document),'-b',provider,'--backend-options',json.dumps(options,separators=(',',':')),'-o',str(job/'output.txt')]
(job/'command.json').write_text(json.dumps(command,indent=2)+'\n')
with (job/'stdout.txt').open('wb') as stdout,(job/'stderr.txt').open('wb') as stderr:p=subprocess.run(command,env=env,cwd=job,stdout=stdout,stderr=stderr)
if route=='cli':
 result={'provider':provider,'route':'actual installed console','success':p.returncode==0,'exit':p.returncode,'input_sha256':expected}
 if (job/'output.txt').exists():result.update(output_bytes=(job/'output.txt').stat().st_size,output_sha256=hashlib.sha256((job/'output.txt').read_bytes()).hexdigest())
 (job/'result.json').write_text(json.dumps(result,indent=2)+'\n')
result=json.loads((job/'result.json').read_text())
with lock.open('a') as handle:
 fcntl.flock(handle,fcntl.LOCK_EX);data=json.loads(ledger.read_text());entry=next(item for item in data['attempts'] if item['key']==key);entry.update(state='success' if result['success'] else 'failed_or_uncertain',exit=p.returncode,result=str(job/'result.json'));temporary=out/'ledger.new.json';temporary.write_text(json.dumps(data,indent=2)+'\n');temporary.replace(ledger)
print(key,'success' if result['success'] else 'FAILED',result.get('output_bytes',''),flush=True)
sys.exit(p.returncode)
