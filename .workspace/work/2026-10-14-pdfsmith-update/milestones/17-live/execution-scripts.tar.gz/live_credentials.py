import os
from pathlib import Path
from dotenv import dotenv_values

ROOT = Path('/home/stefan/applied-ai/pdfsmith')
ALLOWED = {
 'AWS_PROFILE','AWS_REGION','AWS_DEFAULT_REGION','AWS_ACCESS_KEY_ID','AWS_SECRET_ACCESS_KEY','AWS_SESSION_TOKEN',
 'AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT','AZURE_DOCUMENT_INTELLIGENCE_KEY',
 'GOOGLE_APPLICATION_CREDENTIALS','GOOGLE_CLOUD_PROJECT','GOOGLE_CLOUD_LOCATION','GOOGLE_DOCUMENT_AI_PROCESSOR_ID',
 'GOOGLE_API_KEY','GEMINI_API_KEY','LLAMA_CLOUD_API_KEY','ANTHROPIC_API_KEY','OPENAI_API_KEY'
}

def configured():
 file = dotenv_values(ROOT/'.env', interpolate=False)
 return {key:os.environ.get(key) or value for key,value in file.items() if key in ALLOWED and (os.environ.get(key) or value)} | {key:value for key,value in os.environ.items() if key in ALLOWED and value}

def environment():
 values = configured()
 environment = {key:value for key,value in os.environ.items() if key in {'PATH','HOME','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR'}}
 environment.update(values)
 environment.update(PYTHONDONTWRITEBYTECODE='1',AWS_EC2_METADATA_DISABLED='true',TMPDIR=str(ROOT/'.workspace/work/2026-10-14-pdfsmith-update/runtime/tmp'))
 assert not any(key.startswith('DATABRICKS') for key in environment)
 return environment

def inventory():
 values=configured();result={key:bool(values.get(key)) for key in ALLOWED}
 for key in ('GOOGLE_APPLICATION_CREDENTIALS',):
  result[key+'_file_exists']=bool(values.get(key) and Path(values[key]).expanduser().is_file())
 result['google_default_adc_exists']=(Path.home()/'.config/gcloud/application_default_credentials.json').is_file()
 profile=values.get('AWS_PROFILE','default')
 import configparser
 parser=configparser.ConfigParser();parser.read(Path.home()/'.aws/credentials')
 result['selected_aws_profile_in_credentials_file']=profile in parser
 return result
