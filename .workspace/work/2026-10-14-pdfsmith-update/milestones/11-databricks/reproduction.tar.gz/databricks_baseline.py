from pathlib import Path
import os,socket,json,tarfile
from unittest.mock import patch
from tests.databricks_transport import databricks_client
from pdfsmith import parse
from databricks.sdk import WorkspaceClient
w=Path('.workspace/work/2026-10-14-pdfsmith-update');m=w/'milestones/11-databricks'
with tarfile.open(m/'before-source.tar.gz','w:gz') as a:a.add('src/pdfsmith/backends/databricks_backend.py',arcname='databricks_backend.py')
def deny(*a,**kw):raise RuntimeError('Network denied')
socket.socket.connect=deny;socket.getaddrinfo=deny
os.environ.update(DATABRICKS_HOST='https://offline.databricks.invalid',DATABRICKS_CLIENT_ID='offline-client',DATABRICKS_CLIENT_SECRET='offline-secret',DATABRICKS_WAREHOUSE_ID='warehouse')
rows=[]
for case in ['complete','page-error','pending','empty-result','malformed-json']:
 c,wire=databricks_client(case)
 with patch('pdfsmith.backends.databricks_backend.WorkspaceClient',return_value=c):
  try:result={'returned':parse(w/'runtime/ocr-fixtures/two-pages.pdf',backend='databricks')}
  except Exception as e:result={'error_type':type(e).__name__,'error':str(e)}
 rows.append(dict(case=case,result=result,calls=wire.calls,client_closed=wire.closed))
(m/'before.json').write_text(json.dumps(rows,indent=2)+'\n');print([(x['case'],x['result']) for x in rows])
