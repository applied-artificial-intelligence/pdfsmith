from pathlib import Path
import io,json,socket,os
from unittest.mock import patch
import boto3,fitz
from botocore.awsrequest import AWSResponse
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.core.credentials import AzureKeyCredential
from azure.core.utils import case_insensitive_dict
from azure.core.pipeline.transport import HttpTransport,HttpResponse
import pdfsmith
r=Path(__file__).parent;path=r/'local-fixtures/two-pages.pdf'
def denied(*a,**kw):raise RuntimeError('No network in SDK baseline')
socket.socket.connect=denied;socket.getaddrinfo=denied;socket.create_connection=denied
class Raw:
 def __init__(self,data):self.data=data
 def stream(self,*a,**kw):yield self.data
class AWSTransport:
 def __init__(self,late=False):self.calls=[];self.late=late;self.closed=False
 def send(self,request):
  self.calls.append(json.loads(request.body))
  if self.late and len(self.calls)==2:status=400;body={'__type':'InvalidParameterException','Message':'Controlled second-page rejection'}
  else:status=200;body={'DocumentMetadata':{'Pages':1},'Blocks':[]}
  return AWSResponse(request.url,status,{'content-type':'application/x-amz-json-1.1','x-amzn-requestid':f'offline-request-{len(self.calls)}'},Raw(json.dumps(body).encode()))
 def close(self):self.closed=True
class AzureResponse(HttpResponse):
 def __init__(self,request,status,data,headers=None):
  super().__init__(request,None);self.status_code=status;self.headers=case_insensitive_dict({'content-type':'application/json',**(headers or {})});self.content_type='application/json';self._body=json.dumps(data).encode()
 def body(self):return self._body
 def read(self):return self._body
 def json(self):return json.loads(self._body)
 def stream_download(self,*a,**kw):yield self._body
 def iter_bytes(self,*a,**kw):yield self._body
class AzureTransport(HttpTransport):
 def __init__(self):self.calls=[];self.closed=False
 def open(self):pass
 def close(self):self.closed=True
 def __enter__(self):return self
 def __exit__(self,*a):self.close()
 def send(self,request,**kw):
  body=request.body
  if hasattr(body,'read'):body=body.read()
  self.calls.append(dict(method=request.method,url=request.url,body_bytes=len(body) if body else 0))
  if request.method=='POST':return AzureResponse(request,202,{}, {'Operation-Location':'https://offline.azure.invalid/documentintelligence/documentModels/prebuilt-read/analyzeResults/offline-job?api-version=2024-11-30','Retry-After':'0'})
  return AzureResponse(request,200,{'status':'succeeded','analyzeResult':{'apiVersion':'2024-11-30','modelId':'prebuilt-read','stringIndexType':'unicodeCodePoint','content':'','pages':[]}})
records=[]
for label,late in [('missing-page-blocks',False),('late-page-error',True)]:
 client=boto3.session.Session().client('textract',region_name='us-east-1',aws_access_key_id='offline-key',aws_secret_access_key='offline-secret')
 transport=AWSTransport(late);client._endpoint.http_session=transport
 documents=[];original=fitz.open
 def opened(*a,**kw):
  doc=original(*a,**kw);documents.append(doc);return doc
 with patch('boto3.client',return_value=client),patch('fitz.open',opened):
  try:
   text=pdfsmith.parse(path,backend='aws_textract');result=dict(returned_text=text)
  except Exception as exc:result=dict(error_type=type(exc).__name__,error=str(exc))
 states=[doc.is_closed for doc in documents]
 records.append(dict(backend='aws_textract',case=label,result=result,native_document_closed=states,client_closed=transport.closed,requests=len(transport.calls)))
 for doc in documents:
  if not doc.is_closed:doc.close()
 client.close()
transport=AzureTransport();client=DocumentIntelligenceClient('https://offline.azure.invalid',AzureKeyCredential('offline-key'),transport=transport,retry_total=0,polling_interval=0)
os.environ['AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT']='https://offline.azure.invalid';os.environ['AZURE_DOCUMENT_INTELLIGENCE_KEY']='offline-key'
with patch('pdfsmith.backends.azure_document_intelligence_backend.DocumentIntelligenceClient',return_value=client):
 try:text=pdfsmith.parse(path,backend='azure_document_intelligence');result=dict(returned_text=text)
 except Exception as exc:result=dict(error_type=type(exc).__name__,error=str(exc))
records.append(dict(backend='azure_document_intelligence',case='missing-pages',result=result,client_closed=transport.closed,requests=transport.calls));client.close()
output=r.parent/'milestones/09-ocr/before.json';output.write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records,indent=2))
